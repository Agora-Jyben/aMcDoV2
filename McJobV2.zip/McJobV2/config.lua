Config = {}

Config.pDepart = { x = -397.34, y = 6078.09, z = 31.5 } -- point service livraison

-- selection ped aléatoire
Config.pedMissionC = {
	[1] = "g_m_y_ballaorig_01",
	[2] = "s_m_y_xmech_02",
	[3] = "g_m_y_lost_03",
	[4] = "cs_karen_daniels",
	[5] = "s_f_y_cop_01",
	[6] = "s_m_m_security_01",
}

-- selection spawn livraison aléatoire
Config.pMission = {
	[1] = {x = 26.77, y = 6605.79, z = 31.47},
	[2] = {x = 1526.78, y = 6615.95, z = 1.33},
	[3] = {x = 1666.37, y = 4771.55, z = 40.94},
	[4] = {x = 1690.82, y = 3871.31, z = 33.83},
	[5] = {x = 1431.32, y = 3682.19, z = 32.87},
	[6] = {x = -3230.72, y = 1079.15, z = 9.84}
	--[EXEMPLE] = {x = EXEMPLE, y = EXEMPLE, z = EXEMPLE} pour rajouter une pos vous devez aussi modifier coter client mission.lua ligne 142
}

-- selection commande aléatoire
Config.repasCommande = {
	[1] = {label = "Menu Happy Meel", item = "sachappymc"},
	[2] = {label = "Menu Mc Chicken", item = "sacmcchicken"},
	[3] = {label = "Menu Nuggets", item = "sacnuggetss"},
	[4] = {label = "Menu Double Cheese", item = "sacdblcheese"},
	[5] = {label = "Menu BigMac", item = "sacbigmc"}
}
