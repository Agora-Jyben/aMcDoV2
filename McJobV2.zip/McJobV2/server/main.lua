ESX                = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

TriggerEvent('esx_phone:registerNumber', 'macdojob', 'macdojob', true, true)

TriggerEvent('esx_society:registerSociety', 'macdojob', 'macdojob', 'society_macdojob', 'society_macdojob', 'society_macdojob', {type = 'private'})

RegisterNetEvent('mcdostock:getStockMcDoItem')
AddEventHandler('mcdostock:getStockMcDoItem', function(itemName, count)
    local xPlayer = ESX.GetPlayerFromId(source)

    TriggerEvent('esx_addoninventory:getSharedInventory', 'society_macdojob', function(inventory)
  
      local item = inventory.getItem(itemName)
  
      if item.count >= count then
        inventory.removeItem(itemName, count)
        xPlayer.addInventoryItem(itemName, count)
      else
        TriggerClientEvent('esx:showNotification', xPlayer.source, ('Montant invalide'))
      end
  
      TriggerClientEvent('esx:showNotification', xPlayer.source, ('vous déposer') .. count .. ' ' .. item.label)
  
    end)
end)


RegisterServerEvent('mcdostock:putStockMcDoItems')
AddEventHandler('mcdostock:putStockMcDoItems', function(itemName, count)
    local xPlayer = ESX.GetPlayerFromId(source)

    TriggerEvent('esx_addoninventory:getSharedInventory', 'society_macdojob', function(inventory)
  
      local item = inventory.getItem(itemName)
  
      if item.count >= 0 then
        xPlayer.removeInventoryItem(itemName, count)
        inventory.addItem(itemName, count)
      else
        TriggerClientEvent('esx:showNotification', xPlayer.source, ('quantitée invalide'))
      end
  
      TriggerClientEvent('esx:showNotification', xPlayer.source, ('vous retirer') .. count .. ' ' .. item.label)
  
    end)
end)

ESX.RegisterServerCallback('mcdostock:getStockMcDoItems', function(source, cb)
	TriggerEvent('esx_addoninventory:getSharedInventory', 'society_macdojob', function(inventory)
		cb(inventory.items)
	end)
end)

ESX.RegisterServerCallback('mcdostock:getPlayerInventory', function(source, cb)
	local xPlayer = ESX.GetPlayerFromId(source)
	local items   = xPlayer.inventory

	cb( { items = items } )
end)

RegisterServerEvent('AnnonceMcDoOuvert')
AddEventHandler('AnnonceMcDoOuvert', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers	= ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], 'MC Donald', '~y~Annonce MC Donald', '~o~Le MC Donald\'s est ~g~ouvert~o~ ! Venez comme vous êtes !', 'CHAR_SAEEDA', 8)
	end
end)

RegisterServerEvent('AnnonceMcDoFermer')
AddEventHandler('AnnonceMcDoFermer', function()
	local _source = source
	local xPlayer = ESX.GetPlayerFromId(_source)
	local xPlayers	= ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], 'MC Donald', '~y~Annonce MC Donald', '~o~Le MC Donald\'s est ~r~fermer~o~ maintenant !', 'CHAR_SAEEDA', 8)
	end
end)

RegisterCommand('persomc', function(source, args, rawCommand)
    local _source = source
    local xPlayer = ESX.GetPlayerFromId(_source)
    if xPlayer.job.name == "macdojob" then
        local src = source
        local msg = rawCommand:sub(10)
        local args = msg
        if player ~= false then
            local name = GetPlayerName(source)
            local xPlayers	= ESX.GetPlayers()
        for i=1, #xPlayers, 1 do
            local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
            TriggerClientEvent('esx:showAdvancedNotification', xPlayers[i], 'MC Donald', '~y~Annonce MC Donald', '~b~ '..msg..'', 'CHAR_SAEEDA', 0)
        end
    else
        TriggerClientEvent('esx:showAdvancedNotification', _source, 'Avertisement', '~r~Erreur' , '~y~Tu n\'es pas membre de cette entreprise pour faire cette commande', 'CHAR_SAEEDA', 0)
    end
else
    TriggerClientEvent('esx:showAdvancedNotification', _source, 'Avertisement', '~r~Erreur' , '~y~Tu n\'es pas membre de cette entreprise pour faire cette commande', 'CHAR_SAEEDA', 0)
end
end, false)

-----------------------------------------------------------------------------------
------------------------------------Frigo------------------------------------------
-----------------------------------------------------------------------------------

RegisterServerEvent('rgobeletf')
AddEventHandler('rgobeletf', function()
	gobeletfrigo()
end)

function gobeletfrigo()
	local item = "gobelet"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('rjambonf')
AddEventHandler('rjambonf', function()
	Jambonfrigo()
end)

function Jambonfrigo()
	local item = "jambon"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('rchampignionf')
AddEventHandler('rchampignionf', function()
	Champignionfrigo()
end)

function Champignionfrigo()
	local item = "champignion"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end


RegisterServerEvent('rpdtf')
AddEventHandler('rpdtf', function()
	PDTfrigo()
end)

function PDTfrigo()
	local item = "frites_cru"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rtomatesf')
AddEventHandler('rtomatesf', function()
	Tomatesfrigo()
end)

function Tomatesfrigo()
	local item = "tomate"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rcornichonsf')
AddEventHandler('rcornichonsf', function()
	RCornichonfrigo()
end)

function RCornichonfrigo()
	local item = "cornichon"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rsaladevf')
AddEventHandler('rsaladevf', function()
	RSaladeVrigo()
end)

function RSaladeVrigo()
	local item = "salade"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rsteackvf')
AddEventHandler('rsteackvf', function()
	RSteackCFrigo()
end)

function RSteackCFrigo()
	local item = "steack_cru"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rblcpouletf')
AddEventHandler('rblcpouletf', function()
	RBlcPouletFrigo()
end)

function RBlcPouletFrigo()
	local item = "blcpoulet_cru"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rpoissonsf')
AddEventHandler('rpoissonsf', function()
	RPoissonsFrigo()
end)

function RPoissonsFrigo()
	local item = "poissons_cru"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rnuggetsf')
AddEventHandler('rnuggetsf', function()
	nuggetsfrigo()
end)

function nuggetsfrigo()
	local item = "nuggets_cru"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('rlaitf')
AddEventHandler('rlaitf', function()
	RLaitFrigo()
end)

function RLaitFrigo()
	local item = "lait"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rmcpain')
AddEventHandler('rmcpain', function()
	RPain()
end)

function RPain()
	local item = "pain"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rfromagef')
AddEventHandler('rfromagef', function()
	RFromageFrigo()
end)

function RFromageFrigo()
	local item = "fromage"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rchantillyf')
AddEventHandler('rchantillyf', function()
	RChantillyFrigo()
end)

function RChantillyFrigo()
	local item = "chantilly"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rcoulisvanif')
AddEventHandler('rcoulisvanif', function()
	RCVanilleFrigo()
end)

function RCVanilleFrigo()
	local item = "couvanille"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rcoulischocf')
AddEventHandler('rcoulischocf', function()
	RCChocolatFrigo()
end)

function RCChocolatFrigo()
	local item = "couchocolat"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

RegisterServerEvent('rcoulisfraif')
AddEventHandler('rcoulisfraif', function()
	RCFraiseFrigo()
end)

function RCFraiseFrigo()
	local item = "coufraise"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Récolte de ~g~WhiteWidow ~y~en cours...")
    end
end

-----------------------------------------------------------------------------------
---------------------------------Frigo Boissons------------------------------------
-----------------------------------------------------------------------------------

RegisterServerEvent('gsprite')
AddEventHandler('gsprite', function()
	spritefrigo()
end)

function spritefrigo()
	local item = "sprite"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('goasis')
AddEventHandler('goasis', function()
	Oasisfrigo()
end)

function Oasisfrigo()
	local item = "oasis"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('gcocacola')
AddEventHandler('gcocacola', function()
	Cocafrigo()
end)

function Cocafrigo()
	local item = "cocacola"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('gbieres')
AddEventHandler('gbieres', function()
	Bierefrigo()
end)

function Bierefrigo()
	local item = "biere"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('geau')
AddEventHandler('geau', function()
	Eaufrigo()
end)

function Eaufrigo()
	local item = "water"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('gjusorange')
AddEventHandler('gjusorange', function()
	Jusfrigo()
end)

function Jusfrigo()
	local item = "jusfruit"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

RegisterServerEvent('gcafe')
AddEventHandler('gcafe', function()
	Cafefrigo()
end)

function Cafefrigo()
	local item = "cafe"
    local limiteitem = 100
    local xPlayer = ESX.GetPlayerFromId(source)
    local nbitemdansinventaire = xPlayer.getInventoryItem(item).count
    

    if nbitemdansinventaire >= limiteitem then
        TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
    else
        xPlayer.addInventoryItem(item, 1)
        --TriggerClientEvent('esx:showNotification', source, "~y~Retrait de ~g~gobelet ~y~en cours...")
    end
end

-----------------------------------------------------------------------------------
--------------------------------Table de cuissons----------------------------------
-----------------------------------------------------------------------------------

steackok = {} --viande

RegisterServerEvent('c_steack')
AddEventHandler('c_steack', function()
    local _source = source
    steackok[source] = true
	CuireSteack(source)
end)

function CuireSteack(source)
    if steackok[source] == true then
        local stcru = "steack_cru"
        local stcui = "steack"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbstcrudansinventaire = xPlayer.getInventoryItem("steack_cru").count
        local nbstcuidansinventaire = xPlayer.getInventoryItem("steack").count
        
        if nbstcuidansinventaire >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            steackok[source] = false
        elseif nbstcrudansinventaire < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de steack cru pour continuer !")
            steackok[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(stcru, 1)
                xPlayer.addInventoryItem(stcui, 1)
                CuireSteack(source)
            end)
        end
    end
end

-----------------------------------------------------------------------------------
-------------------------------------Friteuse-------------------------------------
-----------------------------------------------------------------------------------

friteok = {} --frites

RegisterServerEvent('c_frites')
AddEventHandler('c_frites', function()
    local _source = source
    friteok[source] = true
	CuireFrites(source)
end)

function CuireFrites(source)
    if friteok[source] == true then
        local fricru = "frites_cru"
        local fricui = "frites"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbstcrudansinventaire = xPlayer.getInventoryItem("frites_cru").count
        local nbstcuidansinventaire = xPlayer.getInventoryItem("frites").count
        
        if nbstcuidansinventaire >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            friteok[source] = false
        elseif nbstcrudansinventaire < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pomme frite pour continuer !")
            friteok[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(fricru, 1)
                xPlayer.addInventoryItem(fricui, 1)
                CuireFrites(source)
            end)
        end
    end
end

nuggetsok = {} --nuugets

RegisterServerEvent('c_nuggets')
AddEventHandler('c_nuggets', function()
    local _source = source
    nuggetsok[source] = true
	CuireNuggets(source)
end)

function CuireNuggets(source)
    if nuggetsok[source] == true then
        local nuggcru = "nuggets_cru"
        local nuggcui = "nuggets"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbstcrudansinventaire = xPlayer.getInventoryItem("nuggets_cru").count
        local nbstcuidansinventaire = xPlayer.getInventoryItem("nuggets").count
        
        if nbstcuidansinventaire >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            nuggetsok[source] = false
        elseif nbstcrudansinventaire < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pomme frite pour continuer !")
            nuggetsok[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(nuggcru, 1)
                xPlayer.addInventoryItem(nuggcui, 1)
                CuireNuggets(source)
            end)
        end
    end
end

chickenkok = {} --chicken

RegisterServerEvent('c_bpoulet')
AddEventHandler('c_bpoulet', function()
    local _source = source
    chickenkok[source] = true
	Cuirechicken(source)
end)

function Cuirechicken(source)
    if chickenkok[source] == true then
        local blcpcru = "blcpoulet_cru"
        local blcpcui = "blcdepoulet"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbstcrudansinventaire = xPlayer.getInventoryItem("blcpoulet_cru").count
        local nbstcuidansinventaire = xPlayer.getInventoryItem("blcdepoulet").count
        
        if nbstcuidansinventaire >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            chickenkok[source] = false
        elseif nbstcrudansinventaire < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pomme frite pour continuer !")
            chickenkok[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(blcpcru, 1)
                xPlayer.addInventoryItem(blcpcui, 1)
                Cuirechicken(source)
            end)
        end
    end
end

-----------------------------------------------------------------------------------
------------------------------------Table Craft------------------------------------
-----------------------------------------------------------------------------------

salade = {}

RegisterServerEvent('csaladev')
AddEventHandler('csaladev', function()
    local _source = source
    salade[source] = true
    McSaladeOk(source)
end)

function McSaladeOk(source)
    if salade[source] == true then
        local salde = "salade"
        local mcsalade = "mc_salade"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsalde = xPlayer.getInventoryItem("salade").count
        local nbmcsalade = xPlayer.getInventoryItem("mc_salade").count
        
        if nbmcsalade >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            salade[source] = false
        elseif nbsalde < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de salade pour continuer !")
            salade[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(salde, 1)
                xPlayer.addInventoryItem(mcsalade, 1)
                TriggerClientEvent('removeactionmc')
                McSaladeOk(source)
            end)
        end
    end
end

saladecomposeee = {}

RegisterServerEvent('csaladecomp')
AddEventHandler('csaladecomp', function()
    local _source = source
    saladecomposeee[source] = true
    McSaladeComposeeOk(source)
end)

function McSaladeComposeeOk(source)
    if saladecomposeee[source] == true then
        local salde = "salade"
        local tomate = "tomate"
        local jambon = "jambon"
        local fromage = "fromage"
        local mcsaladecomposee = "saladecomposee"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsalde = xPlayer.getInventoryItem("salade").count
        local nbtomate = xPlayer.getInventoryItem("tomate").count
        local nbjambon = xPlayer.getInventoryItem("jambon").count
        local nbfromage = xPlayer.getInventoryItem("fromage").count
        local nbmcsaladecomposee = xPlayer.getInventoryItem("saladecomposee").count
        
        if nbmcsaladecomposee >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            saladecomposeee[source] = false
        elseif nbsalde < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de salade pour continuer !")
            saladecomposeee[source] = false
        elseif nbtomate < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Tomate pour continuer !")
            saladecomposeee[source] = false
        elseif nbjambon < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Jambon pour continuer !")
            saladecomposeee[source] = false
        elseif nbfromage < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de fromage pour continuer !")
            saladecomposeee[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(salde, 1)
                xPlayer.removeInventoryItem(tomate, 1)
                xPlayer.removeInventoryItem(jambon, 1)
                xPlayer.removeInventoryItem(fromage, 1)
                xPlayer.addInventoryItem(mcsaladecomposee, 1)
                TriggerClientEvent('removeactionmc')
                McSaladeComposeeOk(source)
            end)
        end
    end
end

saladecesarc = {}

RegisterServerEvent('csaladecesars')
AddEventHandler('csaladecesars', function()
    local _source = source
    saladecesarc[source] = true
    McSaladeCesarc(source)
end)

function McSaladeCesarc(source)
    if saladecesarc[source] == true then
        local salde = "salade"
        local tomate = "tomate"
        local jambon = "jambon"
        local fromage = "fromage"
        local champigion = "champignion"
        local mcsaladecesar = "salade_cesar"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsalde = xPlayer.getInventoryItem("salade").count
        local nbtomate = xPlayer.getInventoryItem("tomate").count
        local nbjambon = xPlayer.getInventoryItem("jambon").count
        local nbfromage = xPlayer.getInventoryItem("fromage").count
        local nbchampigion = xPlayer.getInventoryItem("champignion").count
        local nbmcsaladecesar = xPlayer.getInventoryItem("salade_cesar").count
        
        if nbmcsaladecesar >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            saladecesarc[source] = false
        elseif nbsalde < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de salade pour continuer !")
            saladecesarc[source] = false
        elseif nbtomate < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Tomate pour continuer !")
            saladecesarc[source] = false
        elseif nbjambon < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Jambon pour continuer !")
            saladecesarc[source] = false
        elseif nbchampigion < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Jambon pour continuer !")
            saladecesarc[source] = false
        elseif nbfromage < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de fromage pour continuer !")
            saladecesarc[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(salde, 1)
                xPlayer.removeInventoryItem(tomate, 1)
                xPlayer.removeInventoryItem(jambon, 1)
                xPlayer.removeInventoryItem(fromage, 1)
                xPlayer.removeInventoryItem(champigion, 1)
                xPlayer.addInventoryItem(mcsaladecesar, 1)
                TriggerClientEvent('removeactionmc')
                McSaladeCesarc(source)
            end)
        end
    end
end

chamb = {}

RegisterServerEvent('c_hamb')
AddEventHandler('c_hamb', function()
    local _source = source
    chamb[source] = true
    McHamb(source)
end)

function McHamb(source)
    if chamb[source] == true then
        local steack = "steack"
        local cornichon = "cornichon"
        local pain = "pain"
        local mchambb = "hamburger"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsteack = xPlayer.getInventoryItem("steack").count
        local nbcornichon= xPlayer.getInventoryItem("cornichon").count
        local nbpain = xPlayer.getInventoryItem("pain").count
        local nbmchambb = xPlayer.getInventoryItem("hamburger").count
        
        if nbmchambb >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            chamb[source] = false
        elseif nbsteack < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de steack pour continuer !")
            chamb[source] = false
        elseif nbcornichon < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de cornichon pour continuer !")
            chamb[source] = false
        elseif nbpain < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pain pour continuer !")
            chamb[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(steack, 1)
                xPlayer.removeInventoryItem(cornichon, 1)
                xPlayer.removeInventoryItem(pain, 1)
                xPlayer.addInventoryItem(mchambb, 1)
                TriggerClientEvent('removeactionmc')
                McHamb(source)
            end)
        end
    end
end

cdcheesee = {}

RegisterServerEvent('cdcheese')
AddEventHandler('cdcheese', function()
    local _source = source
    cdcheesee[source] = true
    Mccdcheesee(source)
end)

function Mccdcheesee(source)
    if cdcheesee[source] == true then
        local steack = "steack"
        local cornichon = "cornichon"
        local pain = "pain"
        local fromage = "fromage"
        local mccheese= "cheese_burger"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsteack = xPlayer.getInventoryItem("steack").count
        local nbcornichon= xPlayer.getInventoryItem("cornichon").count
        local nbpain = xPlayer.getInventoryItem("pain").count
        local nbfromage = xPlayer.getInventoryItem("fromage").count
        local nbmccheese = xPlayer.getInventoryItem("cheese_burger").count
        
        if nbmccheese >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            cdcheesee[source] = false
        elseif nbsteack < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de steack pour continuer !")
            cdcheesee[source] = false
        elseif nbcornichon < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de cornichon pour continuer !")
            cdcheesee[source] = false
        elseif nbpain < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pain pour continuer !")
            cdcheesee[source] = false
        elseif nbfromage < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de fromage pour continuer !")
            cdcheesee[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(steack, 1)
                xPlayer.removeInventoryItem(cornichon, 1)
                xPlayer.removeInventoryItem(pain, 1)
                xPlayer.removeInventoryItem(fromage, 2)
                xPlayer.addInventoryItem(mccheese, 1)
                TriggerClientEvent('removeactionmc')
                Mccdcheesee(source)
            end)
        end
    end
end


cbigmacc = {}

RegisterServerEvent('cbigmac')
AddEventHandler('cbigmac', function()
    local _source = source
    cbigmacc[source] = true
    MccBigMac(source)
end)

function MccBigMac(source)
    if cbigmacc[source] == true then
        local salade = "salade"
        local steack = "steack"
        local cornichon = "cornichon"
        local pain = "pain"
        local fromage = "fromage"
        local mcbigmac = "bigmac"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsalade = xPlayer.getInventoryItem("salade").count
        local nbsteack = xPlayer.getInventoryItem("steack").count
        local nbcornichon= xPlayer.getInventoryItem("cornichon").count
        local nbpain = xPlayer.getInventoryItem("pain").count
        local nbfromage = xPlayer.getInventoryItem("fromage").count
        local nbbigmac = xPlayer.getInventoryItem("bigmac").count
        
        if nbbigmac >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            cbigmacc[source] = false
        elseif nbsalade < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de salade pour continuer !")
            cbigmacc[source] = false
        elseif nbsteack < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de steack pour continuer !")
            cbigmacc[source] = false
        elseif nbcornichon < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de cornichon pour continuer !")
            cbigmacc[source] = false
        elseif nbpain < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pain pour continuer !")
            cbigmacc[source] = false
        elseif nbfromage < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de fromage pour continuer !")
            cbigmacc[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(salade, 2)
                xPlayer.removeInventoryItem(steack, 2)
                xPlayer.removeInventoryItem(cornichon, 2)
                xPlayer.removeInventoryItem(pain, 2)
                xPlayer.removeInventoryItem(fromage, 2)
                xPlayer.addInventoryItem(mcbigmac, 1)
                TriggerClientEvent('removeactionmc')
                MccBigMac(source)
            end)
        end
    end
end

cmcchickenn = {}

RegisterServerEvent('cmcchicken')
AddEventHandler('cmcchicken', function()
    local _source = source
    cmcchickenn[source] = true
    MccChickenMc(source)
end)

function MccChickenMc(source)
    if cmcchickenn[source] == true then
        local salade = "salade"
        local blcdepoulet = "blcdepoulet"
        local pain = "pain"
        local fromage = "fromage"
        local mcchicken = "mcchicken"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbsalade = xPlayer.getInventoryItem("salade").count
        local nbblcdepoulet = xPlayer.getInventoryItem("blcdepoulet").count
        local nbpain = xPlayer.getInventoryItem("pain").count
        local nbfromage = xPlayer.getInventoryItem("fromage").count
        local nbmcchicken = xPlayer.getInventoryItem("mcchicken").count
        
        if nbmcchicken >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            cmcchickenn[source] = false
        elseif nbsalade < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de salade pour continuer !")
            cmcchickenn[source] = false
        elseif nbblcdepoulet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de steack pour continuer !")
            cmcchickenn[source] = false
        elseif nbpain < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de pain pour continuer !")
            cmcchickenn[source] = false
        elseif nbfromage < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de fromage pour continuer !")
            cmcchickenn[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(salade, 1)
                xPlayer.removeInventoryItem(blcdepoulet, 1)
                xPlayer.removeInventoryItem(pain, 1)
                xPlayer.removeInventoryItem(fromage, 1)
                xPlayer.addInventoryItem(mcchicken, 1)
                TriggerClientEvent('removeactionmc')
                MccChickenMc(source)
            end)
        end
    end
end
-----------------------------------------------------------------------------------
-------------------------------------Dessert---------------------------------------
-----------------------------------------------------------------------------------

sundeanaturee = {}

RegisterServerEvent('c_sundeanat')
AddEventHandler('c_sundeanat', function()
    local _source = source
    sundeanaturee[source] = true
    Sundeanature(source)
end)

function Sundeanature(source)
    if sundeanaturee[source] == true then
        local gobelet = "gobelet"
        local lait = "lait"
        local chantilly = "chantilly"
        local sundeanatt = "sundaenat"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbgobelet = xPlayer.getInventoryItem("gobelet").count
        local nblait = xPlayer.getInventoryItem("lait").count
        local nbchantilly = xPlayer.getInventoryItem("chantilly").count
        local nbsundeanat = xPlayer.getInventoryItem("sundaenat").count
        
        if nbsundeanat >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            sundeanaturee[source] = false
        elseif nbgobelet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de gobelet pour continuer !")
            sundeanaturee[source] = false
        elseif nblait < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de lait pour continuer !")
            sundeanaturee[source] = false
        elseif nbchantilly < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de chantilly pour continuer !")
            sundeanaturee[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(gobelet, 1)
                xPlayer.removeInventoryItem(lait, 1)
                xPlayer.removeInventoryItem(chantilly, 1)
                xPlayer.addInventoryItem(sundeanatt, 1)
                TriggerClientEvent('removeactionmc')
                Sundeanature(source)
            end)
        end
    end
end

sundeavani = {}

RegisterServerEvent('c_sundeavani')
AddEventHandler('c_sundeavani', function()
    local _source = source
    sundeavani[source] = true
    Sundeavanillle(source)
end)

function Sundeavanillle(source)
    if sundeavani[source] == true then
        local gobelet = "gobelet"
        local lait = "lait"
        local chantilly = "chantilly"
        local vanille = "couvanille"
        local sundeavanille = "sundaevanille"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbgobelet = xPlayer.getInventoryItem("gobelet").count
        local nblait = xPlayer.getInventoryItem("lait").count
        local nbchantilly = xPlayer.getInventoryItem("chantilly").count
        local nbvanille = xPlayer.getInventoryItem("couvanille").count
        local nbsundeavanille = xPlayer.getInventoryItem("sundaevanille").count
        
        if nbsundeavanille >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            sundeavani[source] = false
        elseif nbgobelet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de gobelet pour continuer !")
            sundeavani[source] = false
        elseif nblait < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de lait pour continuer !")
            sundeavani[source] = false
        elseif nbvanille < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de coulis vanille pour continuer !")
            sundeavani[source] = false
        elseif nbchantilly < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de chantilly pour continuer !")
            sundeavani[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(gobelet, 1)
                xPlayer.removeInventoryItem(lait, 1)
                xPlayer.removeInventoryItem(vanille, 1)
                xPlayer.removeInventoryItem(chantilly, 1)
                xPlayer.addInventoryItem(sundeavanille, 1)
                Sundeavanillle(source)
            end)
        end
    end
end

sundeachoco = {}

RegisterServerEvent('c_sundeachoc')
AddEventHandler('c_sundeachoc', function()
    local _source = source
    sundeachoco[source] = true
    SundeaChococolat(source)
end)

function SundeaChococolat(source)
    if sundeachoco[source] == true then
        local gobelet = "gobelet"
        local lait = "lait"
        local chantilly = "chantilly"
        local chocolat = "couchocolat"
        local sundeachococo = "sundaecho"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbgobelet = xPlayer.getInventoryItem("gobelet").count
        local nblait = xPlayer.getInventoryItem("lait").count
        local nbchantilly = xPlayer.getInventoryItem("chantilly").count
        local nbvhovolat = xPlayer.getInventoryItem("couchocolat").count
        local sundeachocolat = xPlayer.getInventoryItem("sundaecho").count
        
        if sundeachocolat >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            sundeachoco[source] = false
        elseif nbgobelet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de gobelet pour continuer !")
            sundeachoco[source] = false
        elseif nblait < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de lait pour continuer !")
            sundeachoco[source] = false
        elseif nbvhovolat < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de coulis chocolat pour continuer !")
            sundeachoco[source] = false
        elseif nbchantilly < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de chantilly pour continuer !")
            sundeachoco[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(gobelet, 1)
                xPlayer.removeInventoryItem(lait, 1)
                xPlayer.removeInventoryItem(chantilly, 1)
                xPlayer.removeInventoryItem(chocolat, 1)
                xPlayer.addInventoryItem(sundeachococo, 1)
                SundeaChococolat(source)
            end)
        end
    end
end


sundeafrai = {}

RegisterServerEvent('c_sundeafraise')
AddEventHandler('c_sundeafraise', function()
    local _source = source
    sundeafrai[source] = true
    SundeaFraise(source)
end)

function SundeaFraise(source)
    if sundeafrai[source] == true then
        local gobelet = "gobelet"
        local lait = "lait"
        local chantilly = "chantilly"
        local fraise = "coufraise"
        local fraisesun = "sundaefrai"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbgobelet = xPlayer.getInventoryItem("gobelet").count
        local nblait = xPlayer.getInventoryItem("lait").count
        local nbchantilly = xPlayer.getInventoryItem("chantilly").count
        local nbfraise = xPlayer.getInventoryItem("coufraise").count
        local nbfraisesun = xPlayer.getInventoryItem("sundaefrai").count
        
        if nbfraisesun >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            sundeafrai[source] = false
        elseif nbgobelet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de gobelet pour continuer !")
            sundeafrai[source] = false
        elseif nblait < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de lait pour continuer !")
            sundeafrai[source] = false
        elseif nbfraise < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de coulis fraise pour continuer !")
            sundeafrai[source] = false
        elseif nbchantilly < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de chantilly pour continuer !")
            sundeafrai[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(gobelet, 1)
                xPlayer.removeInventoryItem(lait, 1)
                xPlayer.removeInventoryItem(chantilly, 1)
                xPlayer.removeInventoryItem(fraise, 1)
                xPlayer.addInventoryItem(fraisesun, 1)
                SundeaFraise(source)
            end)
        end
    end
end


gflurry = {}

RegisterServerEvent('c_flurry')
AddEventHandler('c_flurry', function()
    local _source = source
    gflurry[source] = true
    CMcFlurry(source)
end)

function CMcFlurry(source)
    if gflurry[source] == true then
        local gobelet = "gobelet"
        local lait = "lait"
        local chantilly = "chantilly"
        local chocolat = "couchocolat"
        local mcfurryy = "mcflurry"
        local limiteitem = 100
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbgobelet = xPlayer.getInventoryItem("gobelet").count
        local nblait = xPlayer.getInventoryItem("lait").count
        local nbchantilly = xPlayer.getInventoryItem("chantilly").count
        local nbvhovolat = xPlayer.getInventoryItem("couchocolat").count
        local nbmcfurryy = xPlayer.getInventoryItem("mcflurry").count
        
        if nbmcfurryy >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            gflurry[source] = false
        elseif nbgobelet < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de gobelet pour continuer !")
            gflurry[source] = false
        elseif nblait < 3 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de lait pour continuer !")
            gflurry[source] = false
        elseif nbvhovolat < 2 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de coulis chocolat pour continuer !")
            gflurry[source] = false
        elseif nbchantilly < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de chantilly pour continuer !")
            gflurry[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(gobelet, 1)
                xPlayer.removeInventoryItem(lait, 3)
                xPlayer.removeInventoryItem(chantilly, 1)
                xPlayer.removeInventoryItem(chocolat, 2)
                xPlayer.addInventoryItem(mcfurryy, 1)
                CMcFlurry(source)
            end)
        end
    end
end

cSacMAC = {}

RegisterServerEvent('McSacHappy')
AddEventHandler('McSacHappy', function()
    local _source = source
    cSacMAC[source] = true
    CSacmchapyy(source)
end)

function CSacmchapyy(source)
    if cSacMAC[source] == true then
        local hamburger = "hamburger"
        local jusfruit = "jusfruit"
        local frites = "frites"
        local sundeachoco = "sundaecho"
        local sachappymc = "sachappymc"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbhamburger = xPlayer.getInventoryItem("hamburger").count
        local nbjusfruit = xPlayer.getInventoryItem("jusfruit").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbsundeachoco = xPlayer.getInventoryItem("sundaecho").count
        local nbsachappymc = xPlayer.getInventoryItem("sachappymc").count
        
        if nbsachappymc >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            cSacMAC[source] = false
        elseif nbhamburger < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez d'hamburger pour continuer !")
            cSacMAC[source] = false
        elseif nbjusfruit < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de jus de fruit pour continuer !")
            cSacMAC[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            cSacMAC[source] = false
        elseif nbsundeachoco < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de sundea chocolat pour continuer !")
            cSacMAC[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(hamburger, 1)
                xPlayer.removeInventoryItem(jusfruit, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(sundeachoco, 1)
                xPlayer.addInventoryItem(sachappymc, 1)
                CSacmchapyy(source)
            end)
        end
    end
end

cSacMACbigMAc = {}

RegisterServerEvent('McSacBigMac')
AddEventHandler('McSacBigMac', function()
    local _source = source
    cSacMACbigMAc[source] = true
    CSacmcbigmacOne(source)
end)

function CSacmcbigmacOne(source)
    if cSacMACbigMAc[source] == true then
        local bigmac = "bigmac"
        local cocacola = "cocacola"
        local frites = "frites"
        local mcflurryy = "mcflurry"
        local sacbigmc = "sacbigmc"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbbigmac = xPlayer.getInventoryItem("bigmac").count
        local nbcocacola = xPlayer.getInventoryItem("cocacola").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbmcflurry = xPlayer.getInventoryItem("mcflurry").count
        local nbsacbigmc = xPlayer.getInventoryItem("sacbigmc").count
        
        if nbsacbigmc >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            cSacMACbigMAc[source] = false
        elseif nbbigmac < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Big Mac pour continuer !")
            cSacMACbigMAc[source] = false
        elseif nbcocacola < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Coca Cola pour continuer !")
            cSacMACbigMAc[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            cSacMACbigMAc[source] = false
        elseif nbmcflurry < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de MC flurry pour continuer !")
            cSacMACbigMAc[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(bigmac, 1)
                xPlayer.removeInventoryItem(cocacola, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(mcflurryy, 1)
                xPlayer.addInventoryItem(sacbigmc, 1)
                CSacmcbigmacOne(source)
            end)
        end
    end
end

SdCheese = {}

RegisterServerEvent('McSacDCheese')
AddEventHandler('McSacDCheese', function()
    local _source = source
    SdCheese[source] = true
    SacdoubleCheese(source)
end)

function SacdoubleCheese(source)
    if SdCheese[source] == true then
        local dblCheese = "doublecheese"
        local spriite = "sprite"
        local frites = "frites"
        local sundaefraii = "sundaefrai"
        local saccheese = "sacdblcheese"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbdblCheese = xPlayer.getInventoryItem("doublecheese").count
        local nbspriite = xPlayer.getInventoryItem("sprite").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbsundaefraii = xPlayer.getInventoryItem("sundaefrai").count
        local nbsaccheese = xPlayer.getInventoryItem("sacdblcheese").count
        
        if nbsaccheese >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            SdCheese[source] = false
        elseif nbdblCheese < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Double cheese pour continuer !")
            SdCheese[source] = false
        elseif nbspriite < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Sprite pour continuer !")
            SdCheese[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            SdCheese[source] = false
        elseif nbsundaefraii < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Sundae fraise pour continuer !")
            SdCheese[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(dblCheese, 1)
                xPlayer.removeInventoryItem(spriite, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(sundaefraii, 1)
                xPlayer.addInventoryItem(saccheese, 1)
                SacdoubleCheese(source)
            end)
        end
    end
end


Snuggets = {}

RegisterServerEvent('McSacNuggets')
AddEventHandler('McSacNuggets', function()
    local _source = source
    Snuggets[source] = true
    SacNuggets(source)
end)

function SacNuggets(source)
    if Snuggets[source] == true then
        local nuuggets = "nuggets"
        local juusfruit = "jusfruit"
        local friites = "frites"
        local sundaefraii = "sundaefrai"
        local sacnuggetsss = "sacnuggetss"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbnuggets = xPlayer.getInventoryItem("nuggets").count
        local nbjuusfruit = xPlayer.getInventoryItem("jusfruit").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbsundaefraii = xPlayer.getInventoryItem("sundaefrai").count
        local nbsacnuggetss = xPlayer.getInventoryItem("sacnuggetss").count
        
        if nbsacnuggetss >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            Snuggets[source] = false
        elseif nbnuggets < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Nuggets pour continuer !")
            Snuggets[source] = false
        elseif nbjuusfruit < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Jus de Fruits pour continuer !")
            Snuggets[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            Snuggets[source] = false
        elseif nbsundaefraii < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Sundae fraise pour continuer !")
            Snuggets[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(nuuggets, 1)
                xPlayer.removeInventoryItem(juusfruit, 1)
                xPlayer.removeInventoryItem(friites, 1)
                xPlayer.removeInventoryItem(sundaefraii, 1)
                xPlayer.addInventoryItem(sacnuggetsss, 1)
                SacNuggets(source)
            end)
        end
    end
end


Smcchicken = {}

RegisterServerEvent('McSacChicken')
AddEventHandler('McSacChicken', function()
    local _source = source
    Smcchicken[source] = true
    SacMCNuggets(source)
end)

function SacMCNuggets(source)
    if Smcchicken[source] == true then
        local mcchicken = "mcchicken"
        local oasis = "oasis"
        local frites = "frites"
        local sundaechoco = "sundaecho"
        local sacmcchicken = "sacmcchicken"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbmcchicken = xPlayer.getInventoryItem("mcchicken").count
        local nboasis = xPlayer.getInventoryItem("oasis").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbsundaechoco = xPlayer.getInventoryItem("sundaecho").count
        local nbsacmcchicken = xPlayer.getInventoryItem("sacmcchicken").count
        
        if nbsacmcchicken >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            Smcchicken[source] = false
        elseif nbmcchicken < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Mc Chicken pour continuer !")
            Smcchicken[source] = false
        elseif nboasis < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez d'Oasis pour continuer !")
            Smcchicken[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            Smcchicken[source] = false
        elseif nbsundaechoco < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Sundae chocolat pour continuer !")
            Smcchicken[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(mcchicken, 1)
                xPlayer.removeInventoryItem(oasis, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(sundaechoco, 1)
                xPlayer.addInventoryItem(sacmcchicken, 1)
                SacMCNuggets(source)
            end)
        end
    end
end

SMcSacCesar = {}

RegisterServerEvent('McSacCesar')
AddEventHandler('McSacCesar', function()
    local _source = source
    SMcSacCesar[source] = true
    SacMCCesar(source)
end)

function SacMCCesar(source)
    if SMcSacCesar[source] == true then
        local mccesar = "salade_cesar"
        local water = "water"
        local frites = "frites"
        local sundaechoco = "sundaecho"
        local sacmccesar = "sacmccesar"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbcesar = xPlayer.getInventoryItem("salade_cesar").count
        local nbwater = xPlayer.getInventoryItem("water").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbsundaechoco = xPlayer.getInventoryItem("sundaecho").count
        local nbsacmccesar = xPlayer.getInventoryItem("sacmccesar").count
        
        if nbsacmccesar >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            SMcSacCesar[source] = false
        elseif nbcesar < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Salade Cesar pour continuer !")
            SMcSacCesar[source] = false
        elseif nbwater < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de bouteille d'eau pour continuer !")
            SMcSacCesar[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            SMcSacCesar[source] = false
        elseif nbsundaechoco < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Sundae chocolat pour continuer !")
            SMcSacCesar[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(mccesar, 1)
                xPlayer.removeInventoryItem(water, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(sundaechoco, 1)
                xPlayer.addInventoryItem(sacmccesar, 1)
                SacMCCesar(source)
            end)
        end
    end
end

SMcSacComposee = {}

RegisterServerEvent('McSacComposee')
AddEventHandler('McSacComposee', function()
    local _source = source
    SMcSacComposee[source] = true
    SacMCComposee(source)
end)

function SacMCComposee(source)
    if SMcSacComposee[source] == true then
        local mccomposee = "saladecomposee"
        local water = "water"
        local frites = "frites"
        local mcflurry = "mcflurry"
        local sacmccomposee = "sacmccomposee"
        local limiteitem = 10
        local xPlayer = ESX.GetPlayerFromId(source)
        local nbmccomposee = xPlayer.getInventoryItem("saladecomposee").count
        local nbwater = xPlayer.getInventoryItem("water").count
        local nbfrites = xPlayer.getInventoryItem("frites").count
        local nbmcflurry = xPlayer.getInventoryItem("mcflurry").count
        local nbsacmccomposee = xPlayer.getInventoryItem("sacmccomposee").count
        
        if nbsacmccomposee >= limiteitem then
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de place dans ton inventaire !")
            SMcSacComposee[source] = false
        elseif nbmccomposee < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Salade Composée pour continuer !")
            SMcSacComposee[source] = false
        elseif nbwater < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de bouteille d'eau pour continuer !")
            SMcSacComposee[source] = false
        elseif nbfrites < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Frites pour continuer !")
            SMcSacComposee[source] = false
        elseif nbmcflurry < 1 then 
            TriggerClientEvent('esx:showNotification', source, "~r~Tu n'as pas assez de Mc Flurry pour continuer !")
            SMcSacComposee[source] = false
        else
            SetTimeout(5000, function()
                xPlayer.removeInventoryItem(mccomposee, 1)
                xPlayer.removeInventoryItem(water, 1)
                xPlayer.removeInventoryItem(frites, 1)
                xPlayer.removeInventoryItem(mcflurry, 1)
                xPlayer.addInventoryItem(sacmccomposee, 1)
                SacMCComposee(source)
            end)
        end
    end
end

-----------------------------------------------------------------------------------
-----------------------------------Stop Action-------------------------------------
-----------------------------------------------------------------------------------

RegisterServerEvent('stopactionmc')
AddEventHandler('stopactionmc', function()
    local _source = source
    steackok[source] = false --viande

    friteok[source] = false --friteuse
    nuggetsok[source] = false --friteuse
    chickenkok[source] = false --friteuse

    sundeanaturee[source] = false --glace
    sundeachoco[source] = false --glace
    sundeavani[source] = false --glace
    gflurry[source] = false --glace
    sundeafrai[source] = false --glace

    salade[source] = false -- table craft
    saladecomposeee[source] = false
    saladecesarc[source] = false
    chamb[source] = false
    cdcheesee[source] = false
    cbigmacc[source] = false
    cmcchickenn[source] = false
end)

RegisterServerEvent('stopactionsacmc')
AddEventHandler('stopactionsacmc', function()
    local _source = source

    cSacMAC[source] = false -- craft sac happy meel 
    cSacMACbigMAc[source] = false
    SdCheese[source] = false
    Snuggets[source] = false
    Smcchicken[source] = false
    SMcSacCesar[source] = false
    SMcSacComposee[source] = false
end)

-----------------------------------------------------------------------------------
----------------------------------Result Mission-----------------------------------
-----------------------------------------------------------------------------------

RegisterServerEvent('tcheckCommande')
AddEventHandler('tcheckCommande', function(commandesR)
    --print("Tckek commande : "..commandesR)
    itemc = commandesR
    print("Tckek commande server : "..itemc)
    local _source = source
	local xPlayer = ESX.GetPlayerFromId(source)
    local pSoc = math.random(25, 55)
    local pJ = math.random(10, 25)
    local invplayer = xPlayer.getInventoryItem(itemc).count

    
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_macdojob', function(account)
        societyAccount = account
    end)
    
    if invplayer >= 1 then
        xPlayer.removeInventoryItem(itemc, 1)
        xPlayer.addMoney(pJ)
        societyAccount.addMoney(pSoc)
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~Vous avez gagner ~b~"..pJ.." ~g~ $ ")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~g~La société gagne ~b~"..pSoc.." ~g~ $ ")
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~b~Client\n~y~Ma Commande est complète, c'est parfait merci !") 
    elseif invplayer < 1 then
        TriggerClientEvent('esx:showNotification', xPlayer.source, "~r~Ma Commande n'est pas complete, je refuse de la prendre !")
    end
end)

-----------------------------------------------------------------------------------
----------------------------------Décrafting Sac-----------------------------------
-----------------------------------------------------------------------------------


ESX.RegisterUsableItem('sachappymc', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sachappymc', 1)
    xPlayer.addInventoryItem('hamburger', 1)
    xPlayer.addInventoryItem('jusfruit', 1)
    xPlayer.addInventoryItem('frites', 1)
    xPlayer.addInventoryItem('sundaecho', 1)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez ouvert votre Menu Happy Meel'))
end)

ESX.RegisterUsableItem('sacbigmc', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sacbigmc', 1)
    xPlayer.addInventoryItem('bigmac', 1)
    xPlayer.addInventoryItem('cocacola', 1)
    xPlayer.addInventoryItem('frites', 1)
    xPlayer.addInventoryItem('mcflurry', 1)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez ouvert votre Menu Big Mac'))
end)

ESX.RegisterUsableItem('sacdblcheese', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sacdblcheese', 1)
    xPlayer.addInventoryItem('doublecheese', 1)
    xPlayer.addInventoryItem('sprite', 1)
    xPlayer.addInventoryItem('frites', 1)
    xPlayer.addInventoryItem('sundaefrai', 1)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez ouvert votre Menu Double Cheese'))
end)

ESX.RegisterUsableItem('sacnuggetss', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sacnuggetss', 1)
    xPlayer.addInventoryItem('nuggets', 6)
    xPlayer.addInventoryItem('jusfruit', 1)
    xPlayer.addInventoryItem('frites', 1)
    xPlayer.addInventoryItem('sundaefrai', 1)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez ouvert votre Menu Nuggets'))
end)

ESX.RegisterUsableItem('sacmcchicken', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sacmcchicken', 1)
    xPlayer.addInventoryItem('mcchicken', 1)
    xPlayer.addInventoryItem('oasis', 1)
    xPlayer.addInventoryItem('frites', 1)
    xPlayer.addInventoryItem('sundaecho', 1)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez ouvert votre Menu Mc Chicken'))
end)