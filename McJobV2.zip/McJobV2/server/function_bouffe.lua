ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


--[[
________________________________________________________________________
------------------------------------------------------------------------|
---------------------------------REPAS----------------------------------|
------------------------------------------------------------------------|
________________________________________________________________________|
]]


ESX.RegisterUsableItem('saladecomposee', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('saladecomposee', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 150000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous mangez une Salade Composée'))
end)

ESX.RegisterUsableItem('salade_cesar', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('salade_cesar', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 150000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous mangez une Salade César'))
end)

ESX.RegisterUsableItem('salade', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('salade', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 90000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous mangez une Salade Verte'))
end)


--[[
________________________________________________________________________
------------------------------------------------------------------------|
-------------------------------BOISSONS---------------------------------|
------------------------------------------------------------------------|
________________________________________________________________________|
]]

ESX.RegisterUsableItem('lait', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('lait', 1)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
    TriggerClientEvent('esx_basicneeds:onDrink', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous buvez du lait'))
end)

ESX.RegisterUsableItem('sprite', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sprite', 1)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
    TriggerClientEvent('esx_basicneeds:onDrink', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous avez buvez un Sprite'))
end)

--[[
________________________________________________________________________
------------------------------------------------------------------------|
--------------------------------DESERTS---------------------------------|
------------------------------------------------------------------------|
________________________________________________________________________|
]]

ESX.RegisterUsableItem('sundaenat', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sundaenat', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 90000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous Mangez un ~b~Sundae Nature'))
end)

ESX.RegisterUsableItem('sundaevanille', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sundaevanille', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 90000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous Mangez un ~b~Sundae Vanille'))
end)

ESX.RegisterUsableItem('sundaecho', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sundaecho', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 90000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous Mangez un ~b~Sundae Chocolat'))
end)

ESX.RegisterUsableItem('sundaefrai', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('sundaefrai', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 90000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 150000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous Mangez un ~b~Sundae Chocolat'))
end)

ESX.RegisterUsableItem('mcflurry', function(source)
	local xPlayer = ESX.GetPlayerFromId(source)

	xPlayer.removeInventoryItem('mcflurry', 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', 110000)
    TriggerClientEvent('esx_status:add', source, 'thirst', 180000)
	TriggerClientEvent('esx_basicneeds:onEat', source)
	TriggerClientEvent('esx:showNotification', source, ('Vous Mangez un ~b~MC Flurry'))
end)