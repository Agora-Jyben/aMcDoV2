ESX = nil

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

local playerPed = GetPlayerPed(-1)

--- F6

RegisterNetEvent("f6mcdo")
AddEventHandler("f6mcdo", function()
    openMenuJobMc()
end)

local f6mcdo = false
    
RMenu.Add('f6mcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('f6mcdo', 'main'):SetSubtitle("~r~Menu Interactions")
RMenu.Add('f6mcdo', 'info', RageUI.CreateSubMenu(RMenu:Get('f6mcdo', 'main'), "~b~Informations", "~b~Informations"))
RMenu.Add('f6mcdo', 'ingredientslist', RageUI.CreateSubMenu(RMenu:Get('f6mcdo', 'main'), "~y~Listing ingrédients", "~b~Liste"))
RMenu.Add('f6mcdo', 'salademc', RageUI.CreateSubMenu(RMenu:Get('f6mcdo', 'ingredientslist'), "~y~Listing ingrédients", "~g~Salades Mc"))
RMenu.Add('f6mcdo', 'burgermc', RageUI.CreateSubMenu(RMenu:Get('f6mcdo', 'ingredientslist'), "~y~Listing ingrédients", "~y~Mc Burger"))
RMenu.Add('f6mcdo', 'dessertmc', RageUI.CreateSubMenu(RMenu:Get('f6mcdo', 'ingredientslist'), "~y~Listing ingrédients", "~b~Mc Dessert"))


RMenu:Get('f6mcdo', 'main').EnableMouse = false
RMenu:Get('f6mcdo', 'main').Closed = function()
    f6mcdo = false
end



function openMenuJobMc()
        if not f6mcdo then
            f6mcdo = true
            RageUI.Visible(RMenu:Get('f6mcdo', 'main'), true)

            Citizen.CreateThread(function()
                while f6mcdo do
                    Citizen.Wait(1)
					RageUI.IsVisible(RMenu:Get('f6mcdo', 'main'), true, true, true, function()
						RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.grade_label.. "")

                        RageUI.ButtonWithStyle("~r~Factures", "~r~Faire une facture.", {RightLabel = "→→"}, true, function(Hovered, Active, Selected) 
                            if (Selected) then
                                local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                if closestPlayer == -1 or closestDistance > 3.0 then
                                    TriggerEvent("esx:showAdvancedNotification", '~r~Facture', '~y~MC Donald', '~r~Il n\'y a personne autour de vous.', 'CHAR_BLOCKED', 'spawn', 8)
                                else
                                ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'billing', {
                                    title = ('Rentrer le montant de la facture')
                                }, function(data, menu)
                    
                                    local amount = tonumber(data.value)
                                    if amount == nil then
                                        ESX.ShowNotification('Mauvais montant')
                                    else
                                        menu.close()
                                        local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
                                        if closestPlayer == -1 or closestDistance > 3.0 then
                                            TriggerEvent("esx:showAdvancedNotification", '~r~Facture', '~y~MC Donald', '~r~Il n\'y a personne autour de vous.', 'CHAR_BLOCKED', 'spawn', 8)
                                        else
                                            TriggerServerEvent('esx_billing:sendBill', GetPlayerServerId(closestPlayer), 'society_macdojob', 'MC Donald', amount)
                    
                                            ESX.ShowNotification('Facture envoyée')
                                        end
                    
                                    end
                            
                    
                                end, function(data, menu)
                                    menu.close()
                                end)
                            end
						end 
					end)
                        RageUI.ButtonWithStyle("~b~Informations", "~b~Annonce à la ville.", {RightLabel = "→→"}, true, function(Hovered, Active, Selected) 
                            if (Selected) then
                            end 
                        end, RMenu:Get('f6mcdo', 'info'))

						RageUI.ButtonWithStyle("~y~Listing ingrédients", "~y~fiche de fabrication.", {RightLabel = "→→"}, true, function(Hovered, Active, Selected) 
                            if (Selected) then
                            end 
                        end, RMenu:Get('f6mcdo', 'ingredientslist'))

                    end, function()
                end)
				
                RageUI.IsVisible(RMenu:Get('f6mcdo', 'info'), true, true, true, function()
					RageUI.ButtonWithStyle("Ouvert", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            TriggerServerEvent('AnnonceMcDoOuvert')
						end 
					end)

					RageUI.ButtonWithStyle("~r~Fermer", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            TriggerServerEvent('AnnonceMcDoFermer')
						end 
					end)

					RageUI.ButtonWithStyle("Annonce personalisée", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            local annoncemc = TannonceMc("Message", "", 100)
							ExecuteCommand("persomc "..annoncemc)
						end 
					end)

				end, function()
                end)
				
				RageUI.IsVisible(RMenu:Get('f6mcdo', 'ingredientslist'), true, true, true, function()
					RageUI.ButtonWithStyle("~g~Salade", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('f6mcdo', 'salademc'))

					RageUI.ButtonWithStyle("~r~Burger", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('f6mcdo', 'burgermc'))

					RageUI.ButtonWithStyle("~p~Dessert", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('f6mcdo', 'dessertmc'))

				end, function()
                end)  
				
				RageUI.IsVisible(RMenu:Get('f6mcdo', 'salademc'), true, true, true, function()
					RageUI.ButtonWithStyle("Salade cézar", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 salade\n~y~X1 fromage\n~r~X1 Jambon\n~r~X1 Champignion"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Salade Composée", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 salade\n~y~X1 jambon\n~r~X1 Tomates\n~y~X1 Fromage"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Salade verte", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X3 salade"
							}
						end 
					end)

				end, function()
                end)

				RageUI.IsVisible(RMenu:Get('f6mcdo', 'burgermc'), true, true, true, function()

					RageUI.ButtonWithStyle("Hamburger", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients ~m~Hamburger~y~]\n~g~X1 steack\n~y~X2 cornichons\n~r~X2 Ketchup\n~y~X2 Pain"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Double cheese", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients ~o~Double cheese~y~]\n~g~X1 steack\n~y~X2 cornichons"
							}
							RageUI.Popup{
								message = "~y~[~b~Ingredients ~o~Double cheese~y~]\n~y~X1 Pain\n~y~X1 Fromage"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Big Mac", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients ~r~Big Mac~y~]\n~g~X2 steack\n~y~X2 cornichons"
							}
							RageUI.Popup{
								message = "~y~[~b~Ingredients ~r~Big Mac~y~]\n~y~X2 Pain\n~y~X2 Fromage\n~g~X2 Salade"
							}
						end 
					end)

					RageUI.ButtonWithStyle("MC Nuggets", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients ~p~MC Nuggets~y~]\n~y~X1 Poulet"
							}
						end 
					end)

					RageUI.ButtonWithStyle("MC Chicken", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients ~p~MC Chicken~y~]\n~g~X1 Salade\n~g~X1 Poulet\n~g~X1 Fromage\nX1 Pain"
							}
						end 
					end)

				end, function()
                end)

				RageUI.IsVisible(RMenu:Get('f6mcdo', 'dessertmc'), true, true, true, function()

					RageUI.ButtonWithStyle("Sundae Nature", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 Gobelet\n~b~X1 Lait\n~r~X1 Chantilly"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Sundae Vanille", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 Gobelet\n~b~X1 Lait\n~r~X1 Chantilly\n~r~X1 Coulis vanille"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Sundae Chocolat", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 Gobelet\n~b~X1 Lait\n~r~X1 Chantilly\n~r~X1 Coulis chocolat"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Sundae FRAISE", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 Gobelet\n~b~X1 Lait\n~r~X1 Chantilly\n~r~X1 Coulis fraise"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Mc Flurry", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Ingredients~y~]\n~g~X1 Gobelet\n~b~X3 Lait\n~r~X1 Chantilly\n~r~X1 Coulis Chocolat"
							}
						end 
					end)

				end, function()
                end)

				RageUI.IsVisible(RMenu:Get('f6mcdo', 'sacmc'), true, true, true, function()

					RageUI.ButtonWithStyle("Menu Happy Meel", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Happy Meel~y~]\n~g~X1 Hamburger\n~b~X1 Jus de Fruits\n~r~X1 Mc Frites"
							}
							RageUI.Popup{
								message = "~y~[~b~Happy Meel~y~]\n~g~X1 Sundae chocolat"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Menu Big Mac", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Menu Big Mac~y~]\n~r~X1 BigMac\n~b~X1 Coca Cola\n~y~X1 Mc Frites\n~w~X1 Mc Flurry"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Menu Double Cheese", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Menu Double Cheese~y~]\n~y~X1 Double Cheese\n~b~X1 Sprite\n~y~X1 Mc Frites\n~w~X1 Sundae Fraise"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Menu Nuggets", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Menu Nuggets~y~]\n~y~X1 Nuggets\n~b~X1 Jus de Fruit\n~y~X1 Mc Frites\n~w~X1 Sundae Fraise"
							}
						end 
					end)

					RageUI.ButtonWithStyle("Menu Mc Chicken", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Menu Mc Chicken~y~]\n~y~X1 Mc Chicken\n~b~X1 Oasis\n~y~X1 Mc Frites\n~w~X1 Sundae Chocolat"
							}
						end 
					end)

				end, function()
                end)
            end
        end)
    end
end

function TannonceMc(TextEntry, ExampleText, MaxStringLenght)


    AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
    DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, " ", "", "", MaxStringLenght)
    blockinput = true

    while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
        Citizen.Wait(0)
    end
        
    if UpdateOnscreenKeyboard() ~= 2 then
        local result = GetOnscreenKeyboardResult() 
        Citizen.Wait(500) 
        blockinput = false
        return result 
    else
        Citizen.Wait(500) 
        blockinput = false 
        return nil 
    end
end

---------------- FONCTIONS BOSS ------------------
local bossmcdo = false

RMenu.Add('bossmcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('bossmcdo', 'main'):SetSubtitle("~p~MC Menu Boss")

RMenu:Get('bossmcdo', 'main').EnableMouse = false
RMenu:Get('bossmcdo', 'main').Closed = function()
    bossmcdo = false
end

function openMenuBossMc()
	if not bossmcdo then
		bossmcdo = true
		RageUI.Visible(RMenu:Get('bossmcdo', 'main'), true)

		Citizen.CreateThread(function()
			while bossmcdo do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('bossmcdo', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("Accéder aux actions du patron", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							actionbmc()
						end 
					end)
				end, function()
				end)
			end
		end)
	end
end

function actionbmc()
    TriggerEvent('esx_society:openBossMenu', 'macdojob', function(data, menu)
        menu.close()
    end, {wash = false})
end

--[[local positionboss = {
    {x = -403.2, y = 6081.25, z = 31.51}
}]]

---------------- FONCTIONS Vestiaire ------------------
local vestiairemcdo = false

RMenu.Add('vestiairemcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('vestiairemcdo', 'main'):SetSubtitle("~y~MC Vestiaire")

RMenu:Get('vestiairemcdo', 'main').EnableMouse = false
RMenu:Get('vestiairemcdo', 'main').Closed = function()
    vestiairemcdo = false
end

function openMenuVestiaireMc()
	if not vestiairemcdo then
		vestiairemcdo = true
		RageUI.Visible(RMenu:Get('vestiairemcdo', 'main'), true)

		Citizen.CreateThread(function()
			while vestiairemcdo do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('vestiairemcdo', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.grade_label.. "")

					RageUI.ButtonWithStyle("Tenue ~b~Civile","Reprendre sa tenue civil", {RightLabel = ""}, true, function(Hovered, Active, Selected)
						if Selected then
							MCcivil()
						end
					end)

					RageUI.Separator("~s~↓ ~b~Tenue de Service ~s~↓")

					RageUI.ButtonWithStyle("Tenue Homme ~r~Mc Donald's","Prendre sa tenue de service", {RightLabel = ""}, true, function(Hovered, Active, Selected)
						if Selected then
							MCTenueH()
						end
					end)

					RageUI.ButtonWithStyle("Tenue Femme ~r~Mc Donald's","Prendre sa tenue de service", {RightLabel = ""}, true, function(Hovered, Active, Selected)
						if Selected then
							MCTenueF()
						end
					end)

				end, function()
				end)
			end
		end)
	end
end

function MCcivil()
    ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
        TriggerEvent('skinchanger:loadSkin', skin)
    end)
end

function MCTenueH()
    local model = GetEntityModel(GetPlayerPed(-1))
    TriggerEvent('skinchanger:getSkin', function(skin)
        if model == GetHashKey("mp_m_freemode_01") then
            clothesSkin = {
                ['bags_1'] = 0, ['bags_2'] = 0,
                ['tshirt_1'] = 15, ['tshirt_2'] = 0,
                ['torso_1'] = 279, ['torso_2'] = 5,
                ['arms'] = 92,
                ['pants_1'] = 50, ['pants_2'] = 2,
                ['shoes_1'] = 25, ['shoes_2'] = 0,
            }
        else
            clothesSkin = {
                ['bags_1'] = 0, ['bags_2'] = 0,
                ['tshirt_1'] = 10,['tshirt_2'] = 0,
                ['torso_1'] = 294, ['torso_2'] = 1,
                ['arms'] = 1, ['arms_2'] = 0,
                ['pants_1'] = 52, ['pants_2'] = 2,
                ['shoes_1'] = 22, ['shoes_2'] = 9,
            }
        end
        TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
    end)
end

function MCTenueF()
    local model = GetEntityModel(GetPlayerPed(-1))
    TriggerEvent('skinchanger:getSkin', function(skin)
        if model == GetHashKey("mp_m_freemode_01") then
            clothesSkin = {
                ['bags_1'] = 0, ['bags_2'] = 0,
                ['tshirt_1'] = 15, ['tshirt_2'] = 0,
                ['torso_1'] = 279, ['torso_2'] = 5,
                ['arms'] = 92,
                ['pants_1'] = 50, ['pants_2'] = 2,
                ['shoes_1'] = 25, ['shoes_2'] = 0,
            }
        else
            clothesSkin = {
                ['bags_1'] = 0, ['bags_2'] = 0,
                ['tshirt_1'] = 10,['tshirt_2'] = 0,
                ['torso_1'] = 294, ['torso_2'] = 1,
                ['arms'] = 1, ['arms_2'] = 0,
                ['pants_1'] = 52, ['pants_2'] = 2,
                ['shoes_1'] = 22, ['shoes_2'] = 9,
            }
        end
        TriggerEvent('skinchanger:loadClothes', skin, clothesSkin)
    end)
end


--[[local positionvestiaire = {
    {x = -401.42, y = 6079.71, z = 31.51}
}]]


---------------- FONCTIONS Frigo ------------------


local frigomenu = false
    
RMenu.Add('frigomenu', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('frigomenu', 'main'):SetSubtitle("~b~MC Frigo")
RMenu.Add('frigomenu', 'list', RageUI.CreateSubMenu(RMenu:Get('frigomenu', 'main'), "~y~Listing Stock", "~b~Liste Stock"))
RMenu.Add('frigomenu', 'legumes', RageUI.CreateSubMenu(RMenu:Get('frigomenu', 'list'), "~g~Listing Legume", "~g~Legumes"))
RMenu.Add('frigomenu', 'viande', RageUI.CreateSubMenu(RMenu:Get('frigomenu', 'list'), "~r~Listing Viande", "~r~Viandes"))
RMenu.Add('frigomenu', 'sucre', RageUI.CreateSubMenu(RMenu:Get('frigomenu', 'list'), "~y~Listing Sucre", "~b~Sucré"))


RMenu:Get('frigomenu', 'main').EnableMouse = false
RMenu:Get('frigomenu', 'main').Closed = function()
    frigomenu = false
end



function openMenuFrigo()
        if not frigomenu then
            frigomenu = true
            RageUI.Visible(RMenu:Get('frigomenu', 'main'), true)

            Citizen.CreateThread(function()
                while frigomenu do
                    Citizen.Wait(1)
					RageUI.IsVisible(RMenu:Get('frigomenu', 'main'), true, true, true, function()
						RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.grade_label.. "")

                        RageUI.ButtonWithStyle("~b~Frigo", "~y~Mc Stock.", {RightLabel = "→→"}, true, function(Hovered, Active, Selected) 
                            if (Selected) then
                            end 
                        end, RMenu:Get('frigomenu', 'list'))

						RageUI.Separator("~s~↓ ~y~Rayon sec ~s~↓")

						RageUI.ButtonWithStyle("MC Gobelet", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
							if (Selected) then 
								RageUI.Popup{
									message = "~y~[~b~Frigo~y~]\n~g~-1 Gobelet"
								}
								TriggerServerEvent("rgobeletf")
							end 
						end)

                    end, function()
                end)
				
				
				RageUI.IsVisible(RMenu:Get('frigomenu', 'list'), true, true, true, function()
					RageUI.ButtonWithStyle("~g~Legumes", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('frigomenu', 'legumes'))

					RageUI.ButtonWithStyle("~r~Viandes", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('frigomenu', 'viande'))

					RageUI.ButtonWithStyle("~b~Sucré", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('frigomenu', 'sucre'))

				end, function()
                end)  
				
				RageUI.IsVisible(RMenu:Get('frigomenu', 'legumes'), true, true, true, function()

					RageUI.ButtonWithStyle("Frites surgelée", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Frites surgeler"
							}
							TriggerServerEvent("rpdtf")
						end 
					end)

					RageUI.ButtonWithStyle("Tomates", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Tomates"
							}
							TriggerServerEvent("rtomatesf")
						end 
					end)

					RageUI.ButtonWithStyle("Cornichons", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Cornichons"
							}
							TriggerServerEvent("rcornichonsf")
						end 
					end)

					RageUI.ButtonWithStyle("Salade", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Salade"
							}
							TriggerServerEvent("rsaladevf")
						end 
					end)

				end, function()
                end)

				RageUI.IsVisible(RMenu:Get('frigomenu', 'viande'), true, true, true, function()

					RageUI.ButtonWithStyle("Jambon", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Jambon"
							}
							TriggerServerEvent("rjambonf")
						end 
					end)

					RageUI.ButtonWithStyle("Steack", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Steack"
							}
							TriggerServerEvent("rsteackvf")
						end 
					end)

					RageUI.ButtonWithStyle("Blanc de poulet", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Blanc de poulet"
							}
							TriggerServerEvent("rblcpouletf")
						end 
					end)

					RageUI.ButtonWithStyle("Poissons", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Poissons"
							}
							TriggerServerEvent("rpoissonsf")
						end 
					end)

					RageUI.ButtonWithStyle("Nuggets surgelée", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Nuggets surgelée"
							}
							TriggerServerEvent("rnuggetsf")
						end 
					end)

				end, function()
                end)

				RageUI.IsVisible(RMenu:Get('frigomenu', 'sucre'), true, true, true, function()

					RageUI.ButtonWithStyle("Lait", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Lait"
							}
							TriggerServerEvent("rlaitf")
						end 
					end)

					RageUI.ButtonWithStyle("Pain", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Pain"
							}
							TriggerServerEvent("rmcpain")
						end 
					end)

					RageUI.ButtonWithStyle("Champignion", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Champigion"
							}
							TriggerServerEvent("rchampignionf")
						end 
					end)

					RageUI.ButtonWithStyle("Fromage", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Fromage"
							}
							TriggerServerEvent("rfromagef")
						end 
					end)

					RageUI.ButtonWithStyle("Chantilly", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Chantilly"
							}
							TriggerServerEvent("rchantillyf")
						end 
					end)

					RageUI.ButtonWithStyle("Coulis de fraise", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Coulis de fraise"
							}
							TriggerServerEvent("rcoulisfraif")
						end 
					end)

					RageUI.ButtonWithStyle("Coulis vanille", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Coulis de vanille"
							}
							TriggerServerEvent("rcoulisvanif")
						end 
					end)

					RageUI.ButtonWithStyle("Coulis de chocolat", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
                            RageUI.Popup{
								message = "~y~[~b~Frigo~y~]\n~g~-1 Coulis de chocolat"
							}
							TriggerServerEvent("rcoulischocf")
						end 
					end)

				end, function()
                end)
            end
        end)
    end
end


--[[local positionmcfrigo = {
    {x = -396.57, y = 6074.35, z = 31.5}
}]]


---------------- FONCTIONS Coffre Objet ------------------
local coffremcdo = false

RMenu.Add('coffremcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('coffremcdo', 'main'):SetSubtitle("~y~MC Coffre")

RMenu:Get('coffremcdo', 'main').EnableMouse = false
RMenu:Get('coffremcdo', 'main').Closed = function()
    coffremcdo = false
end

function openMenuCoffreMc()
	if not coffremcdo then
		coffremcdo = true
		RageUI.Visible(RMenu:Get('coffremcdo', 'main'), true)

		Citizen.CreateThread(function()
			while coffremcdo do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('coffremcdo', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.grade_label.. "")

					RageUI.ButtonWithStyle("~r~Retirer~b~ un objet(s)",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							OpenGetCoffreMenuMC()
							ESX.ShowColoredNotification('~g~Action effectuée.', 18) 
						end
					end)
		
					RageUI.ButtonWithStyle("~g~Déposer~b~ un Objet(s)",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							OpenPutCoffreMenuMC()
							ESX.ShowNotification('~g~Action effectuée.', 18) 
						end
					end)
				end, function()
				end)
			end
		end)
	end
end

--[[local positioncoffre = {
    {x = -404.88, y = 6082.31, z = 31.52}
}]]

function OpenGetCoffreMenuMC()
	coffremcdo = false

	ESX.TriggerServerCallback('mcdostock:getStockMcDoItems', function(items)

		local elements = {}

		for i=1, #items, 1 do
			table.insert(elements, {
				label = 'x' .. items[i].count .. ' ' .. items[i].label,
				value = items[i].name
			})
		end

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'stocks_menu_mcdo',
		{
			title    = ('Mcdo_stock'),
			align    = 'top-left',
			elements = elements
		}, function(data, menu)

			local itemName = data.current.value

			ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'stocks_menu_mcdo_get_item_count', {
				title = ('quantitée')
			}, function(data2, menu2)

				local count = tonumber(data2.value)

				if count == nil then
					ESX.ShowNotification('quantitée invalide')
				else
					menu2.close()
					menu.close()
					TriggerServerEvent('mcdostock:getStockMcDoItem', itemName, count)

					Citizen.Wait(300)
					OpenGetCoffreMenuMC()
				end

			end, function(data2, menu2)
				menu2.close()
			end)

		end, function(data, menu)
			menu.close()
		end)

	end)

end

function OpenPutCoffreMenuMC()

	ESX.TriggerServerCallback('mcdostock:getPlayerInventory', function(inventory)

		local elements = {}

		for i=1, #inventory.items, 1 do
			local item = inventory.items[i]

			if item.count > 0 then
				table.insert(elements, {
					label = item.label .. ' x' .. item.count,
					type = 'item_standard',
					value = item.name
				})
			end
		end

		ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'stocks_menu_mcdo',
		{
			title    = ('inventaire'),
			align    = 'top-left',
			elements = elements
		}, function(data, menu)

			local itemName = data.current.value

			ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'stocks_menu_mcdo_put_item_count', {
				title = ('quantitée')
			}, function(data2, menu2)

				local count = tonumber(data2.value)

				if count == nil then
					ESX.ShowNotification('quantitée invalide')
				else
					menu2.close()
					menu.close()
					TriggerServerEvent('mcdostock:putStockMcDoItems', itemName, count)

					Citizen.Wait(300)
					OpenPutCoffreMenuMC()
				end

			end, function(data2, menu2)
				menu2.close()
			end)

		end, function(data, menu)
			menu.close()
		end)
	end)

end


---------------- FONCTIONS Garage ------------------
local garagemcdo = false

RMenu.Add('garagemcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('garagemcdo', 'main'):SetSubtitle("~b~MC Garage")

RMenu:Get('garagemcdo', 'main').EnableMouse = false
RMenu:Get('garagemcdo', 'main').Closed = function()
    garagemcdo = false
end

function openMenuGarageMc()
	if not garagemcdo then
		garagemcdo = true
		RageUI.Visible(RMenu:Get('garagemcdo', 'main'), true)

		Citizen.CreateThread(function()
			while garagemcdo do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('garagemcdo', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.grade_label.. "")

					RageUI.ButtonWithStyle("~r~Ranger~w~ le véhicule",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							local veh,dist4 = ESX.Game.GetClosestVehicle(playerCoords)
							if dist4 < 4 then
								ESX.ShowAdvancedNotification("~y~Mc Donald's", "Vehicule ranger !", "", "CHAR_SOCIAL_CLUB", 1)
                				DeleteEntity(veh)
            				end
						end
					end)
		
					RageUI.ButtonWithStyle("~o~Sortir~w~ la Camionette ", "~o~Pour sortir la camionette", {RightLabel = "→→→"},true, function(Hovered, Active, Selected)
						if (Selected) then
							ESX.ShowAdvancedNotification("~y~Mc Donald's", "Le vehicule arrive !", "", "CHAR_SOCIAL_CLUB", 1) 
							Citizen.Wait(2000)   
							spawnMcdoCar("vwcaddy")
							ESX.ShowAdvancedNotification("~y~Mc Donald's", "Abimez pas le véhicule !", "", "CHAR_SOCIAL_CLUB", 1) 
						end
					end)  
					
					RageUI.ButtonWithStyle("~o~Sortir~w~ le Camion", "~o~Pour sortir le Camion", {RightLabel = "→→→"},true, function(Hovered, Active, Selected)
						if (Selected) then
							ESX.ShowAdvancedNotification("~y~Mc Donald's", "Le vehicule arrive !", "", "CHAR_SOCIAL_CLUB", 1) 
							Citizen.Wait(2000)   
							spawnMcdoCar2("fordcargo")
							ESX.ShowAdvancedNotification("~y~Mc Donald's", "Abimez pas le véhicule !", "", "CHAR_SOCIAL_CLUB", 1) 
						end
					end) 

				end, function()
				end)
			end
		end)
	end
end

function spawnMcdoCar(car)
    local car = GetHashKey(car)

    RequestModel(car)
    while not HasModelLoaded(car) do
        RequestModel(car)
        Citizen.Wait(0)
    end

    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle = CreateVehicle(car, -357.59, 6071.23, 30.5, 313.36, true, false)
    SetEntityAsMissionEntity(vehicle, true, true)
    local plaque = "macdo"
    SetVehicleNumberPlateText(vehicle, plaque) 
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle,-1) 
end

function spawnMcdoCar2(car2)
    local car2 = GetHashKey(car2)

    RequestModel(car2)
    while not HasModelLoaded(car2) do
        RequestModel(car2)
        Citizen.Wait(0)
    end

    local x, y, z = table.unpack(GetEntityCoords(GetPlayerPed(-1), false))
    local vehicle2 = CreateVehicle(car2, -357.59, 6071.23, 30.5, 313.36, true, false)
    SetEntityAsMissionEntity(vehicle2, true, true)
    local plaque = "macdo2"
    SetVehicleNumberPlateText(vehicle2, plaque) 
    SetPedIntoVehicle(GetPlayerPed(-1),vehicle2,-1) 
end

--[[local positiongarage = {
    {x = -358.93, y = 6062.14, z = 31.5}
}]]


---------------- FONCTIONS Boissons ------------------
local boissonsmcdo = false

RMenu.Add('boissonsmcdo', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('boissonsmcdo', 'main'):SetSubtitle("~y~MC Boissons")

RMenu:Get('boissonsmcdo', 'main').EnableMouse = false
RMenu:Get('boissonsmcdo', 'main').Closed = function()
    boissonsmcdo = false
end

function openMenuBoissonsMc()
	if not boissonsmcdo then
		boissonsmcdo = true
		RageUI.Visible(RMenu:Get('boissonsmcdo', 'main'), true)

		Citizen.CreateThread(function()
			while boissonsmcdo do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('boissonsmcdo', 'main'), true, true, true, function()
					RageUI.Separator("~s~↓ ~b~Boissons Gazeuses ~s~↓")

					RageUI.ButtonWithStyle("~w~Sprite",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("gsprite")
						end
					end)
		
					RageUI.ButtonWithStyle("~r~Coca-Cola",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("gcocacola")
						end
					end)

					RageUI.ButtonWithStyle("~y~Bières",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("gbieres")
						end
					end)

					RageUI.Separator("~s~↓ ~o~Autres Boissons~s~ ↓")

					RageUI.ButtonWithStyle("~b~Eau",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("geau")
						end
					end)
		
					RageUI.ButtonWithStyle("~o~Jus d'orange",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("gjusorange")
						end
					end)

					RageUI.ButtonWithStyle("~y~Oasis",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("goasis")
						end
					end)

					RageUI.ButtonWithStyle("~m~Café",nil, {RightLabel = ">>"}, true, function(Hovered, Active, Selected)
						if Selected then
							TriggerServerEvent("gcafe")
						end
					end)

				end, function()
				end)
			end
		end)
	end
end

--[[local positionboissons = {
    {x = -395.05, y = 6067.92, z = 31.5}
}]]

local pos = {
	positionboss = {
		{x = -403.2, y = 6081.25, z = 31.51}
	},

	positionvestiaire = {
		{x = -401.42, y = 6079.71, z = 31.51}
	},

	positionmcfrigo = {
		{x = -396.57, y = 6074.35, z = 31.5}
	},

	positioncoffre = {
		{x = -404.88, y = 6082.31, z = 31.52}
	},

	positiongarage = {
		{x = -358.93, y = 6062.14, z = 31.5}
	},

	positionboissons = {
		{x = -395.05, y = 6067.92, z = 31.5}
	},
}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)

		if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then
			if IsControlJustReleased(0, 167) then
				--TriggerEvent('f6mcdo')
				openMenuJobMc()
			end
		else
			Citizen.Wait(500)
		end

		for k in pairs(pos.positiongarage) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distgar = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positiongarage[k].x, pos.positiongarage[k].y, pos.positiongarage[k].z)
			if distgar <= 5.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -358.93,  6062.14, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 0, 125, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if distgar <= 3.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au Garage")
						if IsControlJustPressed(1,51) then
							openMenuGarageMc()
						end
					end
				end
			end
        end

        for k in pairs(pos.positionboissons) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local dist = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positionboissons[k].x, pos.positionboissons[k].y, pos.positionboissons[k].z)
			if dist <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -395.05,  6067.92, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 0, 255, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if dist <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au ~b~Frigo boissons")
						if IsControlJustPressed(1,51) then
							openMenuBoissonsMc()
						end
					end
				end
			end
        end

		for k in pairs(pos.positioncoffre) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distcof = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positioncoffre[k].x, pos.positioncoffre[k].y, pos.positioncoffre[k].z)
			if distcof <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -404.88,  6082.31, 30.52+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 0, 255, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if distcof <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au ~o~coffre")
						if IsControlJustPressed(1,51) then
							openMenuCoffreMc()
						end
					end
				end
			end
        end

		for k in pairs(pos.positionboss) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distbss = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positionboss[k].x, pos.positionboss[k].y, pos.positionboss[k].z)
			if distbss <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -403.2, 6081.25, 30.51+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if distbss <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au ~p~Actions Patron")
						if IsControlJustPressed(1,51) then
							openMenuBossMc()
						end
					end
				end
			end
        end

		for k in pairs(pos.positionmcfrigo) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distfrig = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positionmcfrigo[k].x, pos.positionmcfrigo[k].y, pos.positionmcfrigo[k].z)
			if distfrig <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(2, -396.57, 6074.35, 31.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 255, 0, 255, 1, 2, 0, nil, nil, 0)
					if distfrig <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au ~b~Frigo")
						if IsControlJustPressed(1,51) then
							openMenuFrigo()
						end
					end
				end
			end
        end

		for k in pairs(pos.positionvestiaire) do

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distvest = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, pos.positionvestiaire[k].x, pos.positionvestiaire[k].y, pos.positionvestiaire[k].z)
			if distvest <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(22, -401.42, 6079.71, 31.51, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.5, 0.5, 0.5, 0, 255, 255, 0, 255, 1, 2, 0, nil, nil, 0)
					if distvest <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au ~y~vestiaire")
						if IsControlJustPressed(1,51) then
							openMenuVestiaireMc()
						end
					end
				end
			end
        end
    end
end)
