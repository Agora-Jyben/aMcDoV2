ESX = nil

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)

local playerPed = GetPlayerPed(-1)

---------------- FONCTIONS Mission ------------------
local missionmc, missionmcrecup = false, false

RMenu.Add('missionjob', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('missionjob', 'main'):SetSubtitle("~p~MC Livraison")

RMenu:Get('missionjob', 'main').EnableMouse = false
RMenu:Get('missionjob', 'main').Closed = function()
    missionmc = false
end

pedmissBlip = nil

function openMenuMissionMc()
	if not missionmc then
		missionmc = true
		RageUI.Visible(RMenu:Get('missionjob', 'main'), true)

		Citizen.CreateThread(function()
			while missionmc do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('missionjob', 'main'), true, false, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("~g~Partir en livraison", "~r~Pensez à avoir asser de stock, petit conseil !", {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if missionmcrecup == false then 
								missionmcrecup = true
								StartMissionMc()
								RageUI.Popup{
									message = "[~r~Mc Donald's~s~]\n~w~Vous avez pris votre service !"
								}
							end
						end
					end)

					RageUI.ButtonWithStyle("~r~Terminer votre service de livraison", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if missionmcrecup == true then 
								RemoveBlip(pedmissBlip)
								
								StopMissionMc()
								RageUI.Popup{
									message = "[~r~Mc Donald's~s~]\n~w~Vous avez pris votre ~r~fin~w~ de service !"
								}
							elseif missionmcrecup == false then 
								RageUI.Popup{
									message = "[~r~Mc Donald's~s~]\n~w~Vous avez déjà pris votre ~r~fin~w~ de service !"
								}
							end
						end
					end)

				end, function()
				end)
			end
		end)
	end
end

local commandesR = {}

function StopMissionMc()
	DeleteEntity(ped)

	SetTimeout(5000, function()
		missionmcrecup = false
	end)

	print("mission terminer a la demande du joueur")
end

--[[function StopMissionMcValide(ped)
	print("suppression en cours du ped")

	SetEntityAsMissionEntity(ped, false, false)
	ClearPedTasksImmediately(ped)
	SetBlockingOfNonTemporaryEvents(ped, false)
	FreezeEntityPosition(ped, false)
	SetEntityInvincible(ped, false)

	SetTimeout(25000, function()
		DeleteEntity(ped)
	end)

	missionmcrecup = false
end]]

local pospedmiss = {}
posone = nil
local ped = {}
local pospedchoisi = nil

function StartMissionMc()
	print("Mission lancer")
	local pospedchoisi = math.random(1, 4)
	local pospedmiss = GetEntityCoords(pedmiss)
	posone = vector3(Config.pMission[pospedchoisi].x, Config.pMission[pospedchoisi].y, Config.pMission[pospedchoisi].z)
	
	pedmiss = Config.pedMissionC[math.random(1, #Config.pedMissionC)]
	pedmiss = string.upper(pedmiss)
	RequestModel(GetHashKey(pedmiss))
	while not HasModelLoaded(GetHashKey(pedmiss)) or not HasCollisionForModelLoaded(GetHashKey(pedmiss)) do
		Wait(1)
	end


	if pedmiss then
		Citizen.CreateThread(function()
			while not HasModelLoaded(pedmiss) do
				RequestModel(pedmiss)
				Wait(20)
			end

			if pospedchoisi > 0 or pospedchoisi <= 6 then

				ped = CreatePed("PED_TYPE_CIVFEMALE", pedmiss, Config.pMission[pospedchoisi].x, Config.pMission[pospedchoisi].y, Config.pMission[pospedchoisi].z, false, true)
				
				SetBlockingOfNonTemporaryEvents(ped, true)
				FreezeEntityPosition(ped, true)
				SetEntityInvincible(ped, true)
				
				print(posone)

			end

			local nbItemsrepas = math.random(1, 5)
			local selectItems = math.random(1, 5)

			if selectItems > 0 or selectItems <= 5 then
				RageUI.Popup{
					message = "~w~[~y~Client~w~]\nBonjour je souhaiterais commander ceci : ~g~"..Config.repasCommande[selectItems].label.." ~w~ ."
				}
				
				commandesR = Config.repasCommande[selectItems].item

				print("Item selectionner : "..commandesR)

				if ped ~= nil then
					pedmissBlip = AddBlipForEntity(ped)

					SetBlipAsFriendly(pedmissBlip, true)
					SetBlipColour(pedmissBlip, 6)
					SetBlipCategory(pedmissBlip, 3)
					SetBlipRoute(pedmissBlip, true)

					SetEntityAsMissionEntity(ped, true, false)
					ClearPedTasksImmediately(ped)
					SetBlockingOfNonTemporaryEvents(ped, true)
				end

				local street = GetStreetNameAtCoord(posone.x, posone.y, posone.x)
				local msg    = nil

				print(street)

				if street ~= 0 then
					msg = string.format('~s~L\'adresse du client ce trouve à~y~ %s', GetStreetNameFromHashKey(street))
				else
					msg = string.format('~s~L\'adresse du client ce trouve à~y~ %s', GetStreetNameFromHashKey(street))
				end

				ESX.ShowNotification(msg)


				Citizen.CreateThread(function()
					while true do
						Citizen.Wait(1)

						local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
						local distmiss = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, Config.pMission[pospedchoisi].x, Config.pMission[pospedchoisi].y, Config.pMission[pospedchoisi].z+1 )
						if distmiss < 1 then

							ESX.ShowHelpNotification("~INPUT_TALK~ pour donner la livraison")

							if IsControlJustPressed(1,51) then
								print("Item transférer au point de livraison : "..commandesR)
								openMenuPnjMissionMc(commandesR)

								SetTimeout(5000, function()

									SetEntityAsMissionEntity(ped, false, false)
									ClearPedTasksImmediately(ped)
									SetBlockingOfNonTemporaryEvents(ped, false)
									FreezeEntityPosition(ped, false)
									SetEntityInvincible(ped, false)

									missionmcrecup = false

									SetTimeout(15000, function()
										DeleteEntity(ped)
										StopMissionMc()
										pospedchoisi = nil
									end)

								end)

								RemoveBlip(pedmissBlip)
							end
						end
					end
				end)
			end

		end)

	end

end

local menusacmc, recupsac = false, false

RMenu.Add('menusac', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('menusac', 'main'):SetSubtitle("~p~MC Livraison")
RMenu.Add('menusac', 'assemblage', RageUI.CreateSubMenu(RMenu:Get('menusac', 'main'), "~y~MC Menu", "~b~Assemblage"))

RMenu:Get('menusac', 'main').EnableMouse = false
RMenu:Get('menusac', 'main').Closed = function()
	local playerPed = PlayerPedId()
	menusacmc = false
	TriggerServerEvent('stopactionsacmc')
	FreezeEntityPosition(playerPed, false)
end

function MenuCraftSacMC()
	if not menusacmc then
		menusacmc = true
		RageUI.Visible(RMenu:Get('menusac', 'main'), true)

		Citizen.CreateThread(function()
			while menusacmc do
				Citizen.Wait(1)
				
				RageUI.IsVisible(RMenu:Get('menusac', 'main'), true, false, true, function()
					
					RageUI.ButtonWithStyle("~u~Préparer un Mc Menu", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end
					end, RMenu:Get('menusac', 'assemblage'))
				end, function()
				end)

				RageUI.IsVisible(RMenu:Get('menusac', 'assemblage'), true, false, true, function()

					RageUI.ButtonWithStyle("~w~Préparer un Mc Menu ~b~Happy Meel", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupsac == false then 
								TriggerServerEvent("McSacHappy")
								ExecuteCommand("e parkingmeter")
								recupsac = true
							elseif recupsac == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								menusacmc = false
								recupsac = false
								TriggerServerEvent('stopactionsacmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end
					end)

					RageUI.ButtonWithStyle("~w~Préparer un Mc Menu ~r~Big Mac", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupsac == false then 
								TriggerServerEvent("McSacBigMac")
								ExecuteCommand("e parkingmeter")
								recupsac = true
							elseif recupsac == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								menusacmc = false
								recupsac = false
								TriggerServerEvent('stopactionsacmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end
					end)

					RageUI.ButtonWithStyle("~w~Préparer un Mc Menu ~y~Double Cheese", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupsac == false then 
								TriggerServerEvent("McSacDCheese")
								ExecuteCommand("e parkingmeter")
								recupsac = true
							elseif recupsac == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								menusacmc = false
								recupsac = false
								TriggerServerEvent('stopactionsacmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end
					end)

					RageUI.ButtonWithStyle("~w~Préparer un Mc Menu ~y~Nuggets", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupsac == false then 
								TriggerServerEvent("McSacNuggets")
								ExecuteCommand("e parkingmeter")
								recupsac = true
							elseif recupsac == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								menusacmc = false
								recupsac = false
								TriggerServerEvent('stopactionsacmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end
					end)

					RageUI.ButtonWithStyle("~w~Préparer un Mc Menu ~y~Mc Chicken", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupsac == false then 
								TriggerServerEvent("McSacChicken")
								ExecuteCommand("e parkingmeter")
								recupsac = true
							elseif recupsac == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								menusacmc = false
								recupsac = false
								TriggerServerEvent('stopactionsacmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end
					end)

				end, function()
				end)
			end
		end)
	end
end


local menupnj = false

RMenu.Add('pnjmenu', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('pnjmenu', 'main'):SetSubtitle("~p~MC Livraison")

RMenu:Get('pnjmenu', 'main').EnableMouse = false
RMenu:Get('pnjmenu', 'main').Closed = function()
    menupnj = false
end

function openMenuPnjMissionMc()
	if not menupnj then
		menupnj = true
		RageUI.Visible(RMenu:Get('pnjmenu', 'main'), true)

		Citizen.CreateThread(function()
			while menupnj do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('pnjmenu', 'main'), true, false, true, function()

					RageUI.ButtonWithStyle("~u~Donner la commande", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							print("ouverture du menu pnj")
							print("Tckek commande : "..commandesR)
							TriggerServerEvent("tcheckCommande", commandesR)
						end
					end)

				end, function()
				end)
			end
		end)
	end
end

TriggerEvent("removepnj")
AddEventHandler('removepnj', function()
	print("appel function StopMissionMcValide")
	StopMissionMcValide()
end)


local poscraftsacmc = {x = -399.38, y = 6070.23, z = 31.5}


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)

        for k in pairs(poscraftsacmc) do
			
			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local distt = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, poscraftsacmc.x, poscraftsacmc.y, poscraftsacmc.z )
			local playerPed = PlayerPedId()
			if distt <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, poscraftsacmc.x, poscraftsacmc.y, poscraftsacmc.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 0, 1, 2, 0, nil, nil, 0)
				
							
					if distt <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder à l'assemblage pour livraison")
						if IsControlJustPressed(1,51) then
							FreezeEntityPosition(playerPed, true)
							MenuCraftSacMC()
						end
					end
				end
			end
		end

		for k in pairs(Config.pDepart) do
			
			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local distt = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, -397.34, 6078.09, 31.5 )
			if distt <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -397.34, 6078.09, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 0, 1, 2, 0, nil, nil, 0)
				
							
					if distt <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder au service de livraison")
						if IsControlJustPressed(1,51) then
							openMenuMissionMc()
						end
					end
				end
			end
		end
	end
end)

TriggerEvent("removemissionmc")
AddEventHandler('removemissionmc', function()
	missionrecup = false
end)

TriggerEvent("removeactionsacmc")
AddEventHandler('removeactionsacmc', function()
	local _source = source
	recupsac = false
end)