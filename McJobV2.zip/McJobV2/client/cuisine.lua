ESX = nil

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
	PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
	PlayerData.job = job
end)

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end

	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(10)
	end

	ESX.PlayerData = ESX.GetPlayerData()
end)


--[[ESX = nil
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(10)
    end
end)]]

local playerPed = GetPlayerPed(-1)

---------------- FONCTIONS Table Craft ------------------
local tablemc, recupcraft = false, false

RMenu.Add('tablemc', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('tablemc', 'main'):SetSubtitle("~p~MC Table")
RMenu.Add('tablemc', 'recettepossible', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'main'), "~y~Recette MC", "~b~Liste"))
RMenu.Add('tablemc', 'mcsalade', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'recettepossible'), "~b~Fabrication", "~g~Salades Mc"))
RMenu.Add('tablemc', 'burgermct', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'recettepossible'), "~y~Fabrication", "~y~Mc Burger"))
--RMenu.Add('tablemc', 'dessertmc', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'recettepossible'), "~y~Fabrication", "~b~Mc Dessert"))

RMenu:Get('tablemc', 'main').EnableMouse = false
RMenu:Get('tablemc', 'main').Closed = function()
	local playerPed = PlayerPedId()
    tablemc = false
	TriggerServerEvent('stopactionmc')
	FreezeEntityPosition(playerPed, false)
end

function openMenuTableMc()
	if not tablemc then
		tablemc = true
		RageUI.Visible(RMenu:Get('tablemc', 'main'), true)

		Citizen.CreateThread(function()
			while tablemc do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('tablemc', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("Péparation d'une MC recette", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('tablemc', 'recettepossible'))
				end, function()
				end)

				RageUI.IsVisible(RMenu:Get('tablemc', 'recettepossible'), true, true, true, function()
					RageUI.ButtonWithStyle("~g~Salade", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('tablemc', 'mcsalade'))

					RageUI.ButtonWithStyle("~r~Burger", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
						end 
					end, RMenu:Get('tablemc', 'burgermct'))

				end, function()
				end)

				RageUI.IsVisible(RMenu:Get('tablemc', 'mcsalade'), true, true, true, function()
					RageUI.ButtonWithStyle("~g~Salade Verte", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupcraft == false then
								TriggerServerEvent("csaladev")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~y~Salade Composée", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then
							if recupcraft == false then
								TriggerServerEvent("csaladecomp")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~y~Salade Césars", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then
							if recupcraft == false then
								TriggerServerEvent("csaladecesars")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

				end, function()
				end)

				RageUI.IsVisible(RMenu:Get('tablemc', 'burgermct'), true, true, true, function()
					RageUI.ButtonWithStyle("~m~Hamburger", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupcraft == false then
								TriggerServerEvent("c_hamb")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~y~Double Cheese", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then
							if recupcraft == false then 
								TriggerServerEvent("cdcheese")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~r~Big Mac", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then
							if recupcraft == false then 
								TriggerServerEvent("cbigmac")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~b~Mc Chicken", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then
							if recupcraft == false then
								TriggerServerEvent("cmcchicken")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic")
								recupcraft = true
							elseif recupcraft == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								tablemc = false
								recupcraft = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

				end, function()
				end)
			end
		end)
	end
end

local positiontable = {
    {x = -393.56, y = 6071.83, z = 31.5},
	{x = -394.91, y = 6073.19, z = 31.5}
}



---------------- FONCTIONS Table Cuissons ------------------
local cuissons, recupcuis = false, false


RMenu.Add('cuissons', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('cuissons', 'main'):SetSubtitle("~r~MC Cuissons")
--RMenu.Add('tablemc', 'dessertmc', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'recettepossible'), "~y~Fabrication", "~b~Mc Dessert"))

RMenu:Get('cuissons', 'main').EnableMouse = false
RMenu:Get('cuissons', 'main').Closed = function()
	local playerPed = PlayerPedId()
    cuissons = false
	TriggerServerEvent('stopactionmc')
	FreezeEntityPosition(playerPed, false)
end

function openMenuCuissonsMc()
	if not cuissons then
		cuissons = true
		RageUI.Visible(RMenu:Get('cuissons', 'main'), true)

		Citizen.CreateThread(function()
			local playerPed = PlayerPedId()
			while cuissons do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('cuissons', 'main'), true, true, true, function()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("~r~Cuire un steack", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupcuis == false then
								ExecuteCommand("e bbq")
								TriggerServerEvent("c_steack")
								FreezeEntityPosition(playerPed, true)
								recupcuis = true
							elseif recupcuis == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								cuissons = false
								recupcuis = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

				end, function()
				end)
			end
		end)
	end
end

local positioncuissons = {
    {x = -391.88, y = 6070.99, z = 31.5},
	{x = -393.4, y = 6069.44, z = 31.5}
}


---------------- FONCTIONS Friteuse ------------------
local friteuse, recupfri = false, false

RMenu.Add('friteuse', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('friteuse', 'main'):SetSubtitle("~y~MC Friture")
--RMenu.Add('tablemc', 'dessertmc', RageUI.CreateSubMenu(RMenu:Get('tablemc', 'recettepossible'), "~y~Fabrication", "~b~Mc Dessert"))

RMenu:Get('friteuse', 'main').EnableMouse = false
RMenu:Get('friteuse', 'main').Closed = function()
	local playerPed = PlayerPedId()
    friteuse = false
	TriggerServerEvent('stopactionmc')
	FreezeEntityPosition(playerPed, false)
end

function openMenuFriteuseMc()
	if not friteuse then
		friteuse = true
		RageUI.Visible(RMenu:Get('friteuse', 'main'), true)

		Citizen.CreateThread(function()
			while friteuse do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('friteuse', 'main'), true, true, true, function()
					local playerPed = PlayerPedId()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("~y~Cuire des nuggets", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if recupfri == false then
								TriggerServerEvent("c_nuggets")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic4")
								recupfri = true
							elseif recupfri == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								friteuse = false
								recupfri = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~y~Cuire un blanc de poulet", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							local playerPed = PlayerPedId()
							if recupfri == false then
								TriggerServerEvent("c_bpoulet")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic4")
								recupfri = true
							elseif recupfri == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								friteuse = false
								recupfri = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~y~Cuire des frites", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							local playerPed = PlayerPedId()
							if recupfri == false then 
								TriggerServerEvent("c_frites")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e mechanic4")
								recupfri = true
							elseif recupfri == true then
								--RageUI.Popup{
									--message = "~y~[~r"..GetPlayerName(PlayerId()).."~y~]\nC'est pas bien d'essayer de glitch hihi !"
								--}
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								friteuse = false
								recupfri = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

				end, function()
				end)
			end
		end)
	end
end

local positionfriteuse = {
    {x = -397.13, y = 6065.28, z = 31.5}
}

---------------- FONCTIONS Glace ------------------
local glace, glacerecup = false, false

RMenu.Add('glace', 'main', RageUI.CreateMenu("~y~Mc Donald's", ""))
RMenu:Get('glace', 'main'):SetSubtitle("~b~Mc Glacière")

RMenu:Get('glace', 'main').EnableMouse = false
RMenu:Get('glace', 'main').Closed = function()
	local playerPed = PlayerPedId()
    glace = false
	TriggerServerEvent('stopactionmc')
	FreezeEntityPosition(playerPed, false)
end

function openMenuGlaceMc()
	if not glace then
		glace = true
		RageUI.Visible(RMenu:Get('glace', 'main'), true)

		Citizen.CreateThread(function()
			while glace do
				Citizen.Wait(1)
				RageUI.IsVisible(RMenu:Get('glace', 'main'), true, true, true, function()
					local playerPed = PlayerPedId()
					RageUI.Separator("~o~"..GetPlayerName(PlayerId()).. "~w~ - ~o~" ..ESX.PlayerData.job.label.. "")

					RageUI.ButtonWithStyle("~b~Sundea Nature", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							local playerPed = PlayerPedId()
							if glacerecup == false then 
								TriggerServerEvent("c_sundeanat")
								ExecuteCommand("e parkingmeter")
								glacerecup = true
							elseif glacerecup == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								glace = false
								glacerecup = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~b~Sundea Fraise", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if glacerecup == false then 
								TriggerServerEvent("c_sundeafraise")
								FreezeEntityPosition(playerPed, true)
								ExecuteCommand("e parkingmeter")
								glacerecup = true
							elseif glacerecup == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								glace = false
								glacerecup = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~b~Sundea Vanille", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if glacerecup == false then 
								TriggerServerEvent("c_sundeavani")
								ExecuteCommand("e parkingmeter")
								glacerecup = true
							elseif glacerecup == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								glace = false
								glacerecup = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~b~Sundea Chocolat", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if glacerecup == false then
								TriggerServerEvent("c_sundeachoc")
								ExecuteCommand("e parkingmeter")
								glacerecup = true
							elseif glacerecup == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								glace = false
								glacerecup = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

					RageUI.ButtonWithStyle("~b~Mc Flurry", nil, {RightLabel = "→"}, true, function(Hovered, Active, Selected) 
						if (Selected) then 
							if glacerecup == false then
								TriggerServerEvent("c_flurry")
								ExecuteCommand("e parkingmeter")
								glacerecup = true
							elseif glacerecup == true then
								RageUI.Popup{
									message = "~y~[~r~"..GetPlayerName(PlayerId()).."~y~]\nLaisse faire le traitement soit pas si presser !\n~r~Aller recommence !"
								}
								glace = false
								glacerecup = false
								TriggerServerEvent('stopactionmc')
								FreezeEntityPosition(playerPed, false)
								RageUI.CloseAll()
							end
						end 
					end)

				end, function()
				end)
			end
		end)
	end
end

local positionglace = {
    {x = -399.5, y = 6072.93, z = 31.5},
	{x = -399.54, y = 6068.22, z = 31.5}
}

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1)

		local playerPed = PlayerPedId()

        for k in pairs(positionglace) do
            --if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 

            local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
            local distgl = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, positionglace[k].x, positionglace[k].y, positionglace[k].z)
			if distgl <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -399.5, 6072.93, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 155, 155, 155, 255, 0, 1, 2, 0, nil, nil, 0)
					DrawMarker(20, -399.54, 6068.22, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 155, 155, 155, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if distgl <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder à la ~b~Glacière")
						if IsControlJustPressed(1,51) then
							FreezeEntityPosition(playerPed, true)
							openMenuGlaceMc()
						end
					end
				end
			end
		end

		for k in pairs(positionfriteuse) do
			--if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 

			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local distfrit = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, positionfriteuse[k].x, positionfriteuse[k].y, positionfriteuse[k].z)
			if distfrit <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -397.13, 6065.28, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 155, 155, 0, 255, 0, 1, 2, 0, nil, nil, 0)

				
					if distfrit <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder à la ~y~Friteuse")
						if IsControlJustPressed(1,51) then
							FreezeEntityPosition(playerPed, true)
							openMenuFriteuseMc()
						end
					end
				end
			end
		end

		for k in pairs(positioncuissons) do
					
			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local distc = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, positioncuissons[k].x, positioncuissons[k].y, positioncuissons[k].z)
			if distc <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -391.88, 6070.99, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 155, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
					DrawMarker(20, -393.4, 6069.44, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 155, 0, 0, 255, 0, 1, 2, 0, nil, nil, 0)
			
						
					if distc <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder à la ~r~table de cuissons")
						if IsControlJustPressed(1,51) then
							FreezeEntityPosition(playerPed, true)
							openMenuCuissonsMc()
						end
					end
				end
			end
		end

		for k in pairs(positiontable) do
			
			local plyCoords = GetEntityCoords(GetPlayerPed(-1), false)
			local distt = Vdist(plyCoords.x, plyCoords.y, plyCoords.z, positiontable[k].x, positiontable[k].y, positiontable[k].z)
			if distt <= 3.0 then
				if ESX.PlayerData.job and ESX.PlayerData.job.name == 'macdojob' then 
					DrawMarker(20, -393.56, 6071.83, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 0, 1, 2, 0, nil, nil, 0)
					DrawMarker(20, -394.91, 6073.19, 30.5+1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.3, 0.3, 0.3, 0, 255, 0, 255, 0, 1, 2, 0, nil, nil, 0)
				
							
					if distt <= 1.0 then
						ESX.ShowHelpNotification("~INPUT_TALK~ pour accéder à la table")
						if IsControlJustPressed(1,51) then
							FreezeEntityPosition(playerPed, true)
							openMenuTableMc()
						end
					end
				end
			end
		end
	end
end)

TriggerEvent("removeactionmc")
AddEventHandler('removeactionmc', function()
	recupcraft = false
	recupcuis = false
	recupfri = false
    glacerecup = false
	recupsac = false
end)