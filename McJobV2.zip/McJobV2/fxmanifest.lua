fx_version 'adamant'

game 'gta5'

description 'McDo Job'


-- RageUI
client_scripts {
    "client/src/client/RMenu.lua",
    "client/src/client/menu/RageUI.lua",
    "client/src/client/menu/Menu.lua",
    "client/src/client/menu/MenuController.lua",

    "client/src/client/components/*.lua",

    "client/src/client/menu/elements/*.lua",

    "client/src/client/menu/items/*.lua",

    "client/src/client/menu/panels/*.lua",

    "client/src/client/menu/windows/*.lua",

}


client_scripts {
	'config.lua',
	'client/menu.lua',
    'client/cuisine.lua',
    'client/mission.lua'
}

server_scripts {
	'config.lua',
	'server/main.lua'
}

dependencies {
    'esx_society',
}
